# Dodge Rush intentionally uses no special ProGuard/R8 rules.
