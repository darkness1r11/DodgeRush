package com.dodgerush

import android.content.Context
import android.graphics.*
import android.graphics.drawable.ColorDrawable
import android.os.Build
import android.os.SystemClock
import android.view.MotionEvent
import android.view.View
import android.view.HapticFeedbackConstants
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt
import kotlin.random.Random

class DodgeRushView(context: Context) : View(context) {
    private enum class Screen { MENU, HOW_TO, SETTINGS, GAME, PAUSE, GAME_OVER }

    private data class Obstacle(
        var x: Float, var y: Float, var w: Float, var h: Float,
        var speed: Float, var rotation: Float, var spin: Float, var kind: Int
    )
    private data class Coin(var x: Float, var y: Float, var r: Float, var speed: Float, var phase: Float)
    private data class Star(var x: Float, var y: Float, var size: Float, var speed: Float, var alpha: Int)
    private data class PowerUp(var x: Float, var y: Float, var r: Float, var speed: Float, var type: Int, var phase: Float)

    private val prefs = GamePrefs(context)
    private val sound = SoundBank(context)
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val glow = Paint(Paint.ANTI_ALIAS_FLAG)
    private val random = Random(System.nanoTime())

    private var screen = Screen.MENU
    private var lastFrame = 0L
    private var globalTime = 0f
    private var elapsed = 0f
    private var score = 0L
    private var runCoins = 0
    private var playerX = 0.5f
    private var targetX = 0.5f
    private var spawnTimer = 0f
    private var coinTimer = 0f
    private var obstacleCount = 0
    private var leftHeld = false
    private var rightHeld = false
    private var pausedBySystem = false
    private var newHigh = false
    private var gridOffset = 0f
    private var shake = 0f
    private var milestone = 0L
    private var milestoneFlash = 0f
    private var powerTimer = 6f
    private var shieldActive = false
    private var slowTimer = 0f
    private var magnetTimer = 0f
    private var particles = mutableListOf<Particle>()
    private val obstacles = mutableListOf<Obstacle>()
    private val coins = mutableListOf<Coin>()
    private val stars = mutableListOf<Star>()
    private val powerUps = mutableListOf<PowerUp>()

    private data class Particle(var x: Float, var y: Float, var vx: Float, var vy: Float, var life: Float, var size: Float)

    init {
        isFocusable = true
        keepScreenOn = true
        paint.typeface = Typeface.create("sans", Typeface.NORMAL)
        glow.maskFilter = BlurMaskFilter(18f, BlurMaskFilter.Blur.NORMAL)
        setBackgroundColor(Color.rgb(7, 11, 22))
        isClickable = true
        requestFocus()
        postInvalidateOnAnimation()
    }

    private fun W() = width.toFloat()
    private fun H() = height.toFloat()

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        val now = SystemClock.uptimeMillis()
        val dt = if (lastFrame == 0L) 0.016f else ((now - lastFrame) / 1000f).coerceAtMost(0.05f)
        lastFrame = now
        if (!pausedBySystem) globalTime += dt
        if (screen == Screen.GAME && !pausedBySystem) update(dt)
        drawBackground(c)
        when (screen) {
            Screen.MENU -> drawMenu(c)
            Screen.HOW_TO -> drawHowTo(c)
            Screen.SETTINGS -> drawSettings(c)
            Screen.GAME -> drawGame(c)
            Screen.PAUSE -> { drawGame(c); drawPause(c) }
            Screen.GAME_OVER -> { drawGame(c); drawGameOver(c) }
        }
        postInvalidateOnAnimation()
    }

    private fun update(dt: Float) {
        elapsed += dt
        val difficulty = 1f + elapsed / 22f
        score = (elapsed * 10.0 * (1f + elapsed / 90f)).toLong()

        ensureStars()
        for (s in stars) {
            s.y += s.speed * dt
            if (s.y > H() + 4f) {
                s.y = -4f
                s.x = random.nextFloat()
            }
        }
        gridOffset = (gridOffset + H() * (0.09f + difficulty * 0.008f) * dt) % (H() * 0.11f)
        shake = max(0f, shake - dt)
        milestoneFlash = max(0f, milestoneFlash - dt)
        slowTimer = max(0f, slowTimer - dt)
        magnetTimer = max(0f, magnetTimer - dt)
        powerTimer -= dt
        if (powerTimer <= 0f) {
            powerTimer = random.nextDouble(9.0, 15.0).toFloat()
            powerUps += PowerUp(
                x = random.nextDouble(0.12, 0.88).toFloat(),
                y = -40f,
                r = min(W(), H()) * 0.026f,
                speed = H() * 0.18f,
                type = random.nextInt(3),
                phase = random.nextFloat() * 6.28f
            )
        }
        val currentMilestone = score / 100L
        if (currentMilestone > milestone) {
            milestone = currentMilestone
            if (milestone > 0L) {
                milestoneFlash = 0.32f
                burst(W() * playerX, H() * 0.84f, 8)
                sound.play("milestone", prefs.sound)
            }
        }

        val moveSpeed = 2.6f
        if (leftHeld) targetX -= moveSpeed * dt
        if (rightHeld) targetX += moveSpeed * dt
        targetX = targetX.coerceIn(0.08f, 0.92f)
        playerX += (targetX - playerX) * min(1f, dt * 13f)

        spawnTimer -= dt
        val spawnInterval = max(0.34f, 0.95f - elapsed * 0.006f)
        if (spawnTimer <= 0f) {
            spawnTimer = spawnInterval
            spawnPattern(difficulty)
        }

        coinTimer -= dt
        if (coinTimer <= 0f) {
            coinTimer = random.nextDouble(1.0, 2.0).toFloat()
            coins += Coin(
                x = random.nextDouble(0.10, 0.90).toFloat(),
                y = -30f,
                r = min(W(), H()) * 0.022f,
                speed = H() * (0.22f + min(0.15f, elapsed / 1800f)),
                phase = random.nextFloat() * 6.28f
            )
        }

        val px = playerX * W()
        val py = H() * 0.84f
        val pr = min(W(), H()) * 0.035f

        val oi = obstacles.iterator()
        while (oi.hasNext()) {
            val o = oi.next()
            o.y += o.speed * dt * if (slowTimer > 0f) 0.55f else 1f
            o.rotation += o.spin * dt
            if (o.y > H() + 100f) oi.remove()
            else if (circleRectCollision(px, py, pr, o.x, o.y, o.w, o.h)) {
                if (shieldActive) {
                    shieldActive = false
                    burst(px, py, 24)
                    shake = 0.10f
                    sound.play("collision", prefs.sound)
                    vibrate(HapticFeedbackConstants.KEYBOARD_TAP)
                    oi.remove()
                } else {
                    crash()
                    return
                }
            }
        }

        val ci = coins.iterator()
        while (ci.hasNext()) {
            val coin = ci.next()
            coin.y += coin.speed * dt
            coin.phase += dt * 5f
            if (coin.y > H() + 60f) ci.remove()
            else if (distance(px, py, coin.x * W(), coin.y) < pr + coin.r * 1.35f + if (magnetTimer > 0f) W() * 0.09f else 0f) {
                runCoins++
                prefs.totalCoins = prefs.totalCoins + 1
                burst(coin.x * W(), coin.y, 14)
                sound.play("coin", prefs.sound)
                vibrate(HapticFeedbackConstants.KEYBOARD_TAP)
                ci.remove()
            }
        }

        val pui = powerUps.iterator()
        while (pui.hasNext()) {
            val power = pui.next()
            power.y += power.speed * dt
            power.phase += dt * 4f
            if (power.y > H() + 60f) pui.remove()
            else if (distance(px, py, power.x * W(), power.y) < pr + power.r * 1.3f) {
                when (power.type) {
                    0 -> shieldActive = true
                    1 -> slowTimer = 5.5f
                    2 -> magnetTimer = 7.0f
                }
                burst(power.x * W(), power.y, 18)
                sound.play("highscore", prefs.sound)
                vibrate(HapticFeedbackConstants.KEYBOARD_TAP)
                pui.remove()
            }
        }

        val pi = particles.iterator()
        while (pi.hasNext()) {
            val p = pi.next()
            p.x += p.vx * dt
            p.y += p.vy * dt
            p.vy += 90f * dt
            p.life -= dt
            if (p.life <= 0) pi.remove()
        }
    }

    private fun spawnPattern(difficulty: Float) {
        obstacleCount++
        val speedBase = H() * (0.22f + min(0.20f, difficulty * 0.018f))
        when (obstacleCount % 6) {
            0, 1 -> addObstacle(random.nextDouble(0.08, 0.88).toFloat(), speedBase, kind = obstacleCount % 3)
            2 -> {
                val x = random.nextDouble(0.18, 0.82).toFloat()
                addObstacle(x - 0.17f, speedBase * 0.96f, 0.13f, kind = 1)
                addObstacle(x + 0.17f, speedBase * 1.02f, 0.13f, kind = 2)
            }
            3 -> {
                val gap = random.nextDouble(0.30, 0.62).toFloat()
                addObstacle(gap - 0.22f, speedBase * 0.94f, 0.16f, kind = 0)
                addObstacle(gap + 0.15f, speedBase * 0.94f, 0.16f, kind = 0)
            }
            4 -> {
                val x = random.nextDouble(0.12, 0.76).toFloat()
                addObstacle(x, speedBase * 1.06f, 0.20f, kind = 2)
            }
            else -> {
                val x = random.nextDouble(0.22, 0.78).toFloat()
                addObstacle(x - 0.12f, speedBase * 0.98f, 0.11f, kind = 1)
                addObstacle(x + 0.12f, speedBase * 1.06f, 0.11f, kind = 1)
            }
        }
    }

    private fun addObstacle(
        normX: Float, speed: Float, widthNorm: Float = 0.20f, kind: Int = random.nextInt(3)
    ) {
        val w = W() * widthNorm.coerceIn(0.10f, 0.22f)
        obstacles += Obstacle(
            x = (normX.coerceIn(0.03f, 0.97f - widthNorm)) * W(),
            y = -H() * 0.10f,
            w = w,
            h = w * random.nextDouble(0.65, 1.05).toFloat(),
            speed = speed * random.nextDouble(0.88, 1.12).toFloat(),
            rotation = random.nextFloat() * 360f,
            spin = random.nextDouble(-70.0, 70.0).toFloat(),
            kind = kind
        )
    }

    private fun ensureStars() {
        if (stars.size >= 42 || W() <= 0f || H() <= 0f) return
        repeat(42 - stars.size) {
            stars += Star(
                x = random.nextFloat(),
                y = random.nextFloat() * H(),
                size = random.nextDouble(0.7, 2.2).toFloat(),
                speed = H() * random.nextDouble(0.012, 0.045).toFloat(),
                alpha = random.nextInt(35, 125)
            )
        }
    }

    private fun crash() {
        sound.play("collision", prefs.sound)
        vibrate(HapticFeedbackConstants.LONG_PRESS)
        burst(playerX * W(), H() * 0.84f, 30)
        shake = 0.22f
        sound.play("gameover", prefs.sound)
        val old = prefs.highScore
        newHigh = score > old
        if (newHigh) {
            prefs.highScore = score
            sound.play("highscore", prefs.sound)
        }
        if (elapsed > prefs.bestTime) prefs.bestTime = elapsed
        screen = Screen.GAME_OVER
    }

    private fun burst(x: Float, y: Float, n: Int) {
        repeat(n) {
            val a = random.nextDouble(0.0, Math.PI * 2).toFloat()
            val s = random.nextDouble(40.0, 180.0).toFloat()
            particles += Particle(x, y, kotlin.math.cos(a) * s, kotlin.math.sin(a) * s, 0.55f, random.nextDouble(2.0, 5.0).toFloat())
        }
    }

    private fun circleRectCollision(cx: Float, cy: Float, r: Float, x: Float, y: Float, w: Float, h: Float): Boolean {
        val nx = cx.coerceIn(x, x + w)
        val ny = cy.coerceIn(y, y + h)
        return distance(cx, cy, nx, ny) < r * 0.88f
    }

    private fun distance(a: Float, b: Float, c: Float, d: Float) =
        sqrt((a - c) * (a - c) + (b - d) * (b - d))

    private fun drawBackground(c: Canvas) {
        c.drawColor(Color.rgb(5, 8, 18))
        paint.shader = LinearGradient(
            0f, 0f, 0f, H(),
            Color.rgb(10, 19, 42), Color.rgb(3, 6, 14),
            Shader.TileMode.CLAMP
        )
        c.drawRect(0f, 0f, W(), H(), paint)
        paint.shader = null

        ensureStars()
        for (s in stars) {
            paint.color = Color.argb(s.alpha, 170, 220, 255)
            c.drawCircle(s.x * W(), s.y, s.size, paint)
        }

        paint.color = Color.argb(18, 90, 220, 255)
        val horizon = H() * 0.47f
        for (i in 0..7) {
            val y = horizon + i * H() * 0.07f + gridOffset
            if (y < H()) c.drawRect(0f, y, W(), y + 1.5f, paint)
        }
        for (i in -5..5) {
            val x = W() / 2f + i * W() * 0.14f
            c.drawRect(x, horizon, x + 1f, H(), paint)
        }

        paint.color = Color.argb(18, 108, 255, 234)
        for (i in 0..10) {
            val y = H() * i / 10f
            c.drawRect(0f, y, W(), y + 1f, paint)
        }
    }

    private fun text(c: Canvas, s: String, x: Float, y: Float, size: Float, color: Int, align: Paint.Align = Paint.Align.LEFT, bold: Boolean = false) {
        paint.shader = null
        paint.style = Paint.Style.FILL
        paint.color = color
        paint.textSize = size
        paint.textAlign = align
        paint.typeface = Typeface.create("sans", if (bold) Typeface.BOLD else Typeface.NORMAL)
        c.drawText(s, x, y, paint)
    }

    private fun button(c: Canvas, label: String, cx: Float, cy: Float, w: Float, h: Float, accent: Boolean = false) {
        paint.style = Paint.Style.FILL
        paint.color = if (accent) Color.rgb(26, 80, 86) else Color.rgb(18, 28, 48)
        c.drawRoundRect(cx - w/2, cy - h/2, cx + w/2, cy + h/2, h/2, h/2, paint)
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 2f
        paint.color = if (accent) Color.rgb(108, 255, 234) else Color.rgb(52, 75, 105)
        c.drawRoundRect(cx - w/2, cy - h/2, cx + w/2, cy + h/2, h/2, h/2, paint)
        paint.style = Paint.Style.FILL
        text(c, label, cx, cy + h*0.13f, h*0.30f, Color.WHITE, Paint.Align.CENTER, true)
    }

    private fun drawTitle(c: Canvas, y: Float) {
        val accent = skinPrimary()
        val pulse = 0.85f + 0.15f * kotlin.math.sin(globalTime * 2.1f)
        glow.color = Color.argb((120 * pulse).toInt().coerceIn(0,255), Color.red(accent), Color.green(accent), Color.blue(accent))
        c.drawCircle(W()/2, y-12f, 45f * pulse, glow)
        text(c, "DODGE", W()/2, y, min(W(), H())*0.11f, Color.WHITE, Paint.Align.CENTER, true)
        text(c, "RUSH", W()/2, y + min(W(), H())*0.09f, min(W(), H())*0.11f, accent, Paint.Align.CENTER, true)
    }

    private fun skinName(): String = when (prefs.skin) {
        1 -> "PLASMA"
        2 -> "GOLD"
        3 -> "TOXIC"
        4 -> "ICE"
        5 -> "SUNSET"
        6 -> "VAPOR"
        7 -> "CRIMSON"
        8 -> "AURORA"
        else -> "NEON"
    }

    private fun skinPrimary(): Int = when (prefs.skin) {
        1 -> Color.rgb(190, 92, 255)
        2 -> Color.rgb(255, 205, 72)
        3 -> Color.rgb(125, 255, 95)
        4 -> Color.rgb(115, 210, 255)
        5 -> Color.rgb(255, 110, 105)
        6 -> Color.rgb(140, 120, 255)
        7 -> Color.rgb(255, 60, 60)
        8 -> Color.rgb(80, 255, 170)
        else -> Color.rgb(108, 255, 234)
    }

    private fun skinAccent(): Int = when (prefs.skin) {
        1 -> Color.rgb(255, 85, 190)
        2 -> Color.rgb(255, 120, 65)
        3 -> Color.rgb(255, 235, 80)
        4 -> Color.rgb(190, 250, 255)
        5 -> Color.rgb(255, 205, 72)
        6 -> Color.rgb(255, 90, 200)
        7 -> Color.rgb(255, 170, 60)
        8 -> Color.rgb(170, 120, 255)
        else -> Color.rgb(255, 90, 150)
    }

    private fun skinSwatchColor(index: Int): Int = when (index) {
        1 -> Color.rgb(190, 92, 255)
        2 -> Color.rgb(255, 205, 72)
        3 -> Color.rgb(125, 255, 95)
        4 -> Color.rgb(115, 210, 255)
        5 -> Color.rgb(255, 110, 105)
        6 -> Color.rgb(140, 120, 255)
        7 -> Color.rgb(255, 60, 60)
        8 -> Color.rgb(80, 255, 170)
        else -> Color.rgb(108, 255, 234)
    }

    private val skinCount = 9

    private fun musicName(): String = when (prefs.musicTrack) {
        1 -> "PULSE"
        2 -> "NIGHT DRIVE"
        3 -> "SUNRISE"
        4 -> "WARP DRIVE"
        else -> "NEON RUN"
    }

    private fun drawMenu(c: Canvas) {
        drawTitle(c, H()*0.20f)
        drawMenuShip(c)
        text(c, "SURVIVE • DODGE • COLLECT", W()/2, H()*0.335f, min(W(),H())*0.034f, Color.rgb(150,175,205), Paint.Align.CENTER, false)
        text(c, skinName(), W()/2, H()*0.385f, min(W(),H())*0.030f, skinPrimary(), Paint.Align.CENTER, true)
        drawSkinDots(c, H()*0.415f)
        val bw = W()*0.66f
        val bh = H()*0.072f
        button(c, "PLAY", W()/2, H()*0.505f, bw, bh, true)
        button(c, "HOW TO PLAY", W()/2, H()*0.60f, bw, bh)
        button(c, "SETTINGS", W()/2, H()*0.695f, bw, bh)
        statsRow(c, H()*0.85f)
    }

    private fun drawSkinDots(c: Canvas, y: Float) {
        val spacing = min(W(), H()) * 0.065f
        val startX = W()/2f - spacing * (skinCount - 1) / 2f
        for (i in 0 until skinCount) {
            val cx = startX + spacing * i
            val color = skinSwatchColor(i)
            val selected = i == prefs.skin
            val r = if (selected) spacing * 0.30f else spacing * 0.22f
            if (selected) {
                glow.color = Color.argb(140, Color.red(color), Color.green(color), Color.blue(color))
                c.drawCircle(cx, y, r * 2.1f, glow)
            }
            paint.style = Paint.Style.FILL
            paint.color = color
            c.drawCircle(cx, y, r, paint)
            if (selected) {
                paint.style = Paint.Style.STROKE
                paint.strokeWidth = 3f
                paint.color = Color.WHITE
                c.drawCircle(cx, y, r * 1.35f, paint)
                paint.style = Paint.Style.FILL
            }
        }
    }

    private fun drawMenuShip(c: Canvas) {
        val px = W() / 2f
        val py = H() * 0.39f + kotlin.math.sin(globalTime * 2.4f) * H() * 0.006f
        val r = min(W(), H()) * 0.025f
        val primary = skinPrimary()
        val accent = skinAccent()
        glow.color = Color.argb(90, Color.red(primary), Color.green(primary), Color.blue(primary))
        c.drawCircle(px, py, r * 2.4f, glow)
        paint.color = primary
        val ship = Path()
        ship.moveTo(px, py - r * 1.5f)
        ship.lineTo(px - r * 1.15f, py + r)
        ship.lineTo(px, py + r * 0.55f)
        ship.lineTo(px + r * 1.15f, py + r)
        ship.close()
        c.drawPath(ship, paint)
        paint.color = accent
        val flame = Path()
        flame.moveTo(px, py + r * 0.6f)
        flame.lineTo(px - r * 0.35f, py + r * 2.0f)
        flame.lineTo(px, py + r * 1.65f)
        flame.lineTo(px + r * 0.35f, py + r * 2.0f)
        flame.close()
        c.drawPath(flame, paint)
    }

    private fun statsRow(c: Canvas, y: Float) {
        val x = W()/2
        text(c, "HIGH SCORE", x - W()*0.30f, y, W()*0.028f, Color.rgb(120,145,175), Paint.Align.CENTER, true)
        text(c, prefs.highScore.toString(), x - W()*0.30f, y + W()*0.045f, W()*0.05f, Color.WHITE, Paint.Align.CENTER, true)
        text(c, "COINS", x, y, W()*0.028f, Color.rgb(120,145,175), Paint.Align.CENTER, true)
        text(c, prefs.totalCoins.toString(), x, y + W()*0.045f, W()*0.05f, Color.rgb(255,214,82), Paint.Align.CENTER, true)
        text(c, "BEST TIME", x + W()*0.30f, y, W()*0.028f, Color.rgb(120,145,175), Paint.Align.CENTER, true)
        text(c, formatTime(prefs.bestTime), x + W()*0.30f, y + W()*0.045f, W()*0.05f, Color.WHITE, Paint.Align.CENTER, true)
    }

    private fun drawHowTo(c: Canvas) {
        text(c, "HOW TO PLAY", W()/2, H()*0.12f, W()*0.075f, Color.WHITE, Paint.Align.CENTER, true)
        text(c, "Move left and right to stay clear of the falling", W()/2, H()*0.28f, W()*0.038f, Color.rgb(190,205,225), Paint.Align.CENTER)
        text(c, "obstacles. Collect glowing coins for your total.", W()/2, H()*0.33f, W()*0.038f, Color.rgb(190,205,225), Paint.Align.CENTER)
        text(c, "The longer you survive, the faster it gets.", W()/2, H()*0.42f, W()*0.038f, Color.rgb(190,205,225), Paint.Align.CENTER)
        text(c, "Touch / drag left or right • Keyboard: A/D or ←/→", W()/2, H()*0.53f, W()*0.033f, Color.rgb(108,255,234), Paint.Align.CENTER)
        text(c, "Power-ups: S = shield • T = slow time • M = coin magnet", W()/2, H()*0.62f, W()*0.030f, Color.rgb(190,205,225), Paint.Align.CENTER)
        text(c, "Change skins and music tracks in Settings.", W()/2, H()*0.68f, W()*0.030f, Color.rgb(190,205,225), Paint.Align.CENTER)
        button(c, "BACK", W()/2, H()*0.80f, W()*0.50f, H()*0.075f)
    }

    private fun drawSettings(c: Canvas) {
        text(c, "SETTINGS", W()/2, H()*0.09f, W()*0.070f, Color.WHITE, Paint.Align.CENTER, true)
        settingRow(c, "SOUND", prefs.sound, H()*0.22f)
        settingRow(c, "MUSIC", prefs.music, H()*0.34f)
        settingRow(c, "VIBRATION", prefs.vibration, H()*0.46f)
        text(c, "SKIN", W()*0.20f, H()*0.585f, W()*0.040f, Color.WHITE, Paint.Align.LEFT, true)
        button(c, skinName(), W()*0.76f, H()*0.57f, W()*0.34f, H()*0.065f, true)
        text(c, "TRACK", W()*0.20f, H()*0.705f, W()*0.040f, Color.WHITE, Paint.Align.LEFT, true)
        button(c, musicName(), W()*0.76f, H()*0.69f, W()*0.40f, H()*0.065f)
        text(c, "Tap SKIN or TRACK to cycle • 9 skins • 5 tracks", W()/2, H()*0.78f, W()*0.027f, Color.rgb(120,145,175), Paint.Align.CENTER)
        button(c, "BACK", W()/2, H()*0.90f, W()*0.50f, H()*0.070f)
    }

    private fun settingRow(c: Canvas, label: String, enabled: Boolean, y: Float) {
        text(c, label, W()*0.20f, y+10f, W()*0.04f, Color.WHITE, Paint.Align.LEFT, true)
        button(c, if (enabled) "ON" else "OFF", W()*0.76f, y, W()*0.24f, H()*0.065f, enabled)
    }

    private fun drawGame(c: Canvas) {
        c.save()
        if (shake > 0f) {
            val amount = 7f * (shake / 0.22f)
            c.translate(
                random.nextFloat() * amount - amount / 2f,
                random.nextFloat() * amount - amount / 2f
            )
        }

        val px = playerX * W()
        val py = H()*0.84f
        val r = min(W(),H())*0.035f

        text(c, "SCORE  $score", W()*0.055f, H()*0.065f, W()*0.042f, Color.WHITE, Paint.Align.LEFT, true)
        text(c, "● $runCoins", W()*0.55f, H()*0.065f, W()*0.042f, Color.rgb(255,214,82), Paint.Align.LEFT, true)
        text(c, "LV ${1 + (elapsed / 22f).toInt()}", W()*0.055f, H()*0.105f, W()*0.028f, Color.rgb(115,235,225), Paint.Align.LEFT, true)
        button(c, "Ⅱ", W()*0.91f, H()*0.055f, W()*0.12f, H()*0.055f)

        val primary = skinPrimary()
        val accent = skinAccent()
        glow.color = Color.argb(115, Color.red(primary), Color.green(primary), Color.blue(primary))
        c.drawCircle(px, py, r*1.9f, glow)

        val pulse = 0.8f + 0.25f * kotlin.math.sin(elapsed * 18f)
        paint.color = accent
        val flame = Path()
        flame.moveTo(px, py + r * 0.45f)
        flame.lineTo(px - r * 0.38f, py + r * (1.7f + pulse))
        flame.lineTo(px, py + r * 1.3f)
        flame.lineTo(px + r * 0.38f, py + r * (1.7f + pulse))
        flame.close()
        c.drawPath(flame, paint)

        paint.color = primary
        paint.style = Paint.Style.FILL
        val ship = Path()
        ship.moveTo(px, py-r*1.35f)
        ship.lineTo(px-r*1.05f, py+r*0.85f)
        ship.lineTo(px-r*0.42f, py+r*0.48f)
        ship.lineTo(px, py+r*0.72f)
        ship.lineTo(px+r*0.42f, py+r*0.48f)
        ship.lineTo(px+r*1.05f, py+r*0.85f)
        ship.close()
        c.drawPath(ship, paint)
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = max(2f, r * 0.10f)
        paint.color = Color.WHITE
        c.drawPath(ship, paint)
        paint.style = Paint.Style.FILL
        paint.color = Color.rgb(7, 30, 40)
        c.drawCircle(px, py-r*0.27f, r*0.30f, paint)

        for (o in obstacles) {
            val cx = o.x + o.w / 2f
            val cy = o.y + o.h / 2f
            val rr = min(o.w, o.h) * 0.20f
            val main = when (o.kind) {
                1 -> Color.rgb(255, 170, 72)
                2 -> Color.rgb(190, 92, 255)
                else -> Color.rgb(255, 78, 120)
            }
            val dark = when (o.kind) {
                1 -> Color.rgb(105, 50, 15)
                2 -> Color.rgb(62, 20, 95)
                else -> Color.rgb(95, 16, 55)
            }
            glow.color = Color.argb(75, Color.red(main), Color.green(main), Color.blue(main))
            c.drawCircle(cx, cy, min(o.w, o.h) * 0.70f, glow)
            c.save()
            c.rotate(o.rotation, cx, cy)
            paint.style = Paint.Style.FILL
            paint.color = main
            c.drawRoundRect(o.x, o.y, o.x+o.w, o.y+o.h, o.w*0.18f, o.w*0.18f, paint)
            paint.color = dark
            c.drawCircle(cx, cy, rr, paint)
            paint.color = Color.argb(180, 255, 255, 255)
            c.drawRect(o.x + o.w*0.16f, o.y + o.h*0.15f, o.x + o.w*0.84f, o.y + o.h*0.22f, paint)
            c.restore()
        }

        for (coin in coins) {
            val pulseCoin = 1f + 0.12f * kotlin.math.sin(coin.phase)
            val cx = coin.x*W()
            glow.color = Color.argb(100, 255, 214, 82)
            c.drawCircle(cx, coin.y, coin.r*1.7f, glow)
            paint.color = Color.rgb(255,214,82)
            c.drawCircle(cx, coin.y, coin.r*pulseCoin, paint)
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = max(2f, coin.r * 0.12f)
            paint.color = Color.WHITE
            c.drawCircle(cx, coin.y, coin.r*0.72f, paint)
            paint.style = Paint.Style.FILL
            paint.color = Color.rgb(130,92,15)
            c.drawCircle(cx, coin.y, coin.r*0.38f, paint)
        }

        for (power in powerUps) {
            val colors = when (power.type) {
                0 -> intArrayOf(108, 255, 234)
                1 -> intArrayOf(190, 92, 255)
                else -> intArrayOf(255, 214, 82)
            }
            val cx = power.x * W()
            val pulse = 1f + 0.10f * kotlin.math.sin(power.phase)
            glow.color = Color.argb(100, colors[0], colors[1], colors[2])
            c.drawCircle(cx, power.y, power.r * 1.9f, glow)
            paint.color = Color.rgb(colors[0], colors[1], colors[2])
            c.drawCircle(cx, power.y, power.r * pulse, paint)
            text(c, when (power.type) { 0 -> "S"; 1 -> "T"; else -> "M" }, cx, power.y + power.r * 0.36f, power.r * 0.95f, Color.rgb(5, 10, 18), Paint.Align.CENTER, true)
        }

        if (shieldActive) {
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = max(2f, r * 0.12f)
            paint.color = skinPrimary()
            c.drawCircle(px, py, r * 2.15f, paint)
            paint.style = Paint.Style.FILL
        }
        if (slowTimer > 0f) text(c, "TIME ${slowTimer.toInt()+1}s", W()*0.52f, H()*0.105f, W()*0.028f, Color.rgb(190,92,255), Paint.Align.LEFT, true)
        if (magnetTimer > 0f) text(c, "MAGNET ${magnetTimer.toInt()+1}s", W()*0.72f, H()*0.105f, W()*0.024f, Color.rgb(255,214,82), Paint.Align.RIGHT, true)

        for (p in particles) {
            paint.color = Color.argb((255f*(p.life/0.55f)).toInt().coerceIn(0,255), 108, 255, 234)
            c.drawCircle(p.x, p.y, p.size, paint)
        }

        if (milestoneFlash > 0f) {
            val a = (180f * (milestoneFlash / 0.32f)).toInt().coerceIn(0,180)
            text(c, "100+ SCORE!", W()/2f, H()*0.18f, W()*0.045f, Color.argb(a, 108, 255, 234), Paint.Align.CENTER, true)
        }
        c.restore()
    }

    private fun drawPause(c: Canvas) {
        overlay(c)
        text(c, "PAUSED", W()/2, H()*0.28f, W()*0.09f, Color.WHITE, Paint.Align.CENTER, true)
        button(c, "RESUME", W()/2, H()*0.44f, W()*0.62f, H()*0.075f, true)
        button(c, "RESTART", W()/2, H()*0.54f, W()*0.62f, H()*0.075f)
        button(c, "MAIN MENU", W()/2, H()*0.64f, W()*0.62f, H()*0.075f)
    }

    private fun drawGameOver(c: Canvas) {
        overlay(c)
        text(c, if (newHigh) "NEW HIGH SCORE!" else "GAME OVER", W()/2, H()*0.25f, W()*0.075f, if (newHigh) Color.rgb(108,255,234) else Color.WHITE, Paint.Align.CENTER, true)
        text(c, "SCORE", W()*0.28f, H()*0.37f, W()*0.03f, Color.rgb(130,155,185), Paint.Align.CENTER, true)
        text(c, score.toString(), W()*0.28f, H()*0.42f, W()*0.055f, Color.WHITE, Paint.Align.CENTER, true)
        text(c, "COINS", W()*0.50f, H()*0.37f, W()*0.03f, Color.rgb(130,155,185), Paint.Align.CENTER, true)
        text(c, runCoins.toString(), W()*0.50f, H()*0.42f, W()*0.055f, Color.rgb(255,214,82), Paint.Align.CENTER, true)
        text(c, "TIME", W()*0.72f, H()*0.37f, W()*0.03f, Color.rgb(130,155,185), Paint.Align.CENTER, true)
        text(c, formatTime(elapsed), W()*0.72f, H()*0.42f, W()*0.055f, Color.WHITE, Paint.Align.CENTER, true)
        button(c, "PLAY AGAIN", W()/2, H()*0.58f, W()*0.65f, H()*0.075f, true)
        button(c, "MAIN MENU", W()/2, H()*0.68f, W()*0.65f, H()*0.075f)
    }

    private fun overlay(c: Canvas) {
        paint.color = Color.argb(195, 3, 7, 15)
        c.drawRect(0f,0f,W(),H(),paint)
    }

    private fun formatTime(t: Float): String {
        val total = t.toInt()
        return "%02d:%02d".format(total / 60, total % 60)
    }

    private fun startGame() {
        screen = Screen.GAME
        elapsed = 0f
        score = 0
        runCoins = 0
        playerX = 0.5f
        targetX = 0.5f
        spawnTimer = 0.15f
        coinTimer = 0.8f
        obstacleCount = 0
        obstacles.clear()
        coins.clear()
        particles.clear()
        newHigh = false
        milestone = 0L
        milestoneFlash = 0f
        shake = 0f
        powerTimer = 6f
        shieldActive = false
        slowTimer = 0f
        magnetTimer = 0f
        powerUps.clear()
        sound.play("button", prefs.sound)
        sound.setMusic(prefs.music, prefs.musicTrack)
    }

    private fun vibrate(type: Int) {
        if (prefs.vibration) performHapticFeedback(type)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val x = e.x
        val y = e.y
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                when (screen) {
                    Screen.MENU -> {
                        val dotSpacing = min(W(), H()) * 0.065f
                        val dotStartX = W()/2f - dotSpacing * (skinCount - 1) / 2f
                        val dotY = H()*0.415f
                        val tappedDot = (0 until skinCount).firstOrNull { i ->
                            abs(x - (dotStartX + dotSpacing * i)) <= dotSpacing/2f && abs(y - dotY) <= dotSpacing/2f
                        }
                        if (tappedDot != null) {
                            prefs.skin = tappedDot
                            sound.play("button", prefs.sound)
                            vibrate(HapticFeedbackConstants.KEYBOARD_TAP)
                        }
                        else if (hit(x,y,W()/2,H()*0.505f,W()*0.66f,H()*0.072f)) startGame()
                        else if (hit(x,y,W()/2,H()*0.60f,W()*0.66f,H()*0.072f)) { screen=Screen.HOW_TO; sound.play("button",prefs.sound) }
                        else if (hit(x,y,W()/2,H()*0.695f,W()*0.66f,H()*0.072f)) { screen=Screen.SETTINGS; sound.play("button",prefs.sound) }
                    }
                    Screen.HOW_TO -> if (hit(x,y,W()/2,H()*0.80f,W()*0.50f,H()*0.075f)) { screen=Screen.MENU; sound.play("button",prefs.sound) }
                    Screen.SETTINGS -> settingsTouch(x,y)
                    Screen.GAME -> {
                        if (hit(x,y,W()*0.91f,H()*0.055f,W()*0.12f,H()*0.055f)) { screen=Screen.PAUSE; sound.play("button",prefs.sound) }
                        else targetX = (x/W()).coerceIn(0.08f,0.92f)
                    }
                    Screen.PAUSE -> pauseTouch(x,y)
                    Screen.GAME_OVER -> gameOverTouch(x,y)
                }
                return true
            }
            MotionEvent.ACTION_MOVE -> if (screen == Screen.GAME) {
                targetX = (x/W()).coerceIn(0.08f,0.92f)
                return true
            }
        }
        return true
    }

    private fun settingsTouch(x:Float,y:Float) {
        when {
            hit(x,y,W()*0.76f,H()*0.22f,W()*0.24f,H()*0.065f) -> { prefs.sound=!prefs.sound; vibrate(HapticFeedbackConstants.KEYBOARD_TAP) }
            hit(x,y,W()*0.76f,H()*0.34f,W()*0.24f,H()*0.065f) -> {
                prefs.music = !prefs.music
                sound.setMusic(prefs.music, prefs.musicTrack)
                vibrate(HapticFeedbackConstants.KEYBOARD_TAP)
            }
            hit(x,y,W()*0.76f,H()*0.46f,W()*0.24f,H()*0.065f) -> { prefs.vibration=!prefs.vibration }
            hit(x,y,W()*0.76f,H()*0.57f,W()*0.34f,H()*0.065f) -> {
                prefs.skin = (prefs.skin + 1) % skinCount
                sound.play("button",prefs.sound)
                vibrate(HapticFeedbackConstants.KEYBOARD_TAP)
            }
            hit(x,y,W()*0.76f,H()*0.69f,W()*0.40f,H()*0.065f) -> {
                prefs.musicTrack = (prefs.musicTrack + 1) % 5
                if (prefs.music) sound.setMusic(true, prefs.musicTrack)
                sound.play("button",prefs.sound)
                vibrate(HapticFeedbackConstants.KEYBOARD_TAP)
            }
            hit(x,y,W()/2,H()*0.90f,W()*0.50f,H()*0.070f) -> { screen=Screen.MENU; sound.play("button",prefs.sound) }
        }
    }

    private fun pauseTouch(x:Float,y:Float) {
        when {
            hit(x,y,W()/2,H()*0.44f,W()*0.62f,H()*0.075f) -> { screen=Screen.GAME; sound.play("button",prefs.sound) }
            hit(x,y,W()/2,H()*0.54f,W()*0.62f,H()*0.075f) -> startGame()
            hit(x,y,W()/2,H()*0.64f,W()*0.62f,H()*0.075f) -> { screen=Screen.MENU; sound.play("button",prefs.sound) }
        }
    }

    private fun gameOverTouch(x:Float,y:Float) {
        when {
            hit(x,y,W()/2,H()*0.58f,W()*0.65f,H()*0.075f) -> startGame()
            hit(x,y,W()/2,H()*0.68f,W()*0.65f,H()*0.075f) -> { screen=Screen.MENU; sound.play("button",prefs.sound) }
        }
    }

    private fun hit(px:Float,py:Float,cx:Float,cy:Float,w:Float,h:Float) =
        abs(px-cx) <= w/2 && abs(py-cy) <= h/2

    fun onAppPause() {
        pausedBySystem = true
        sound.pauseMusic()
        if (screen == Screen.GAME) screen = Screen.PAUSE
    }

    fun onAppResume() {
        pausedBySystem = false
        lastFrame = SystemClock.uptimeMillis()
        if (screen == Screen.GAME || (screen == Screen.PAUSE && prefs.music)) sound.resumeMusic(prefs.music, prefs.musicTrack)
    }

    override fun onKeyDown(keyCode: Int, event: android.view.KeyEvent): Boolean {
        if (screen == Screen.GAME) {
            when (keyCode) {
                android.view.KeyEvent.KEYCODE_A, android.view.KeyEvent.KEYCODE_DPAD_LEFT -> { leftHeld=true; return true }
                android.view.KeyEvent.KEYCODE_D, android.view.KeyEvent.KEYCODE_DPAD_RIGHT -> { rightHeld=true; return true }
                android.view.KeyEvent.KEYCODE_ESCAPE -> { screen=Screen.PAUSE; return true }
            }
        }
        return super.onKeyDown(keyCode,event)
    }

    override fun onKeyUp(keyCode: Int, event: android.view.KeyEvent): Boolean {
        when (keyCode) {
            android.view.KeyEvent.KEYCODE_A, android.view.KeyEvent.KEYCODE_DPAD_LEFT -> leftHeld=false
            android.view.KeyEvent.KEYCODE_D, android.view.KeyEvent.KEYCODE_DPAD_RIGHT -> rightHeld=false
        }
        return super.onKeyUp(keyCode,event)
    }

    override fun onDetachedFromWindow() {
        sound.release()
        super.onDetachedFromWindow()
    }
}
