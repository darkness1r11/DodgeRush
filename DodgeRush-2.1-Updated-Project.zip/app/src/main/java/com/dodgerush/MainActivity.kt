package com.dodgerush

import android.app.Activity
import android.os.Bundle
import android.view.Window
import android.view.WindowManager

class MainActivity : Activity() {
    private lateinit var gameView: DodgeRushView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        window.setFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN,
            WindowManager.LayoutParams.FLAG_FULLSCREEN
        )
        gameView = DodgeRushView(this)
        setContentView(gameView)
    }

    override fun onPause() {
        super.onPause()
        gameView.onAppPause()
    }

    override fun onResume() {
        super.onResume()
        if (::gameView.isInitialized) gameView.onAppResume()
    }
}
