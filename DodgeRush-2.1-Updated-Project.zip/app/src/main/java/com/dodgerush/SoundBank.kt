package com.dodgerush

import android.content.Context
import android.media.AudioAttributes
import android.media.SoundPool
import java.io.File
import java.io.FileOutputStream
import kotlin.math.PI
import kotlin.math.sin

class SoundBank(private val context: Context) {
    private val pool = SoundPool.Builder()
        .setMaxStreams(4)
        .setAudioAttributes(
            AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_GAME)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()
        )
        .build()

    private val ids = mutableMapOf<String, Int>()
    private var musicStream = 0

    init {
        load("coin", 880.0, 0.10, 0.25)
        load("button", 520.0, 0.06, 0.18)
        load("collision", 90.0, 0.18, 0.30)
        load("gameover", 180.0, 0.28, 0.28)
        load("highscore", 660.0, 0.35, 0.28)
        load("milestone", 1040.0, 0.10, 0.20)
        loadMusicTracks()
    }

    private fun loadMusicTracks() {
        // 0 Neon Run, 1 Pulse, 2 Night Drive, 3 Sunrise, 4 Warp Drive
        val patterns = arrayOf(
            doubleArrayOf(220.0, 277.18, 329.63, 277.18, 196.0, 246.94, 293.66, 246.94),
            doubleArrayOf(261.63, 329.63, 392.0, 523.25, 392.0, 329.63, 293.66, 246.94),
            doubleArrayOf(146.83, 220.0, 174.61, 261.63, 196.0, 293.66, 220.0, 329.63),
            doubleArrayOf(196.0, 246.94, 293.66, 329.63, 392.0, 329.63, 293.66, 246.94),
            doubleArrayOf(329.63, 392.0, 493.88, 587.33, 493.88, 392.0, 329.63, 246.94)
        )
        patterns.forEachIndexed { index, notes ->
            val file = File(context.cacheDir, "music_$index.wav")
            if (!file.exists()) createMusic(file, notes, index)
            ids["music_$index"] = pool.load(file.absolutePath, 1)
        }
    }

    private fun createMusic(file: File, notes: DoubleArray, track: Int) {
        val sampleRate = 22050
        val seconds = 8.0
        val count = (sampleRate * seconds).toInt()
        FileOutputStream(file).use { out ->
            val dataSize = count * 2
            fun le(v: Int) {
                out.write(v and 255); out.write((v shr 8) and 255)
                out.write((v shr 16) and 255); out.write((v shr 24) and 255)
            }
            out.write("RIFF".toByteArray()); le(36 + dataSize)
            out.write("WAVEfmt ".toByteArray())
            le(16); out.write(1); out.write(0); out.write(1); out.write(0)
            le(sampleRate); le(sampleRate * 2); out.write(2); out.write(0)
            out.write(16); out.write(0); out.write("data".toByteArray()); le(dataSize)
            val beats = doubleArrayOf(0.50, 0.40, 0.30, 0.60, 0.22)
            val beat = beats[track.coerceIn(0, beats.size - 1)]
            for (i in 0 until count) {
                val t = i.toDouble() / sampleRate
                val noteIndex = (t / beat).toInt() % notes.size
                val local = (t % beat) / beat
                val fade = minOf(1.0, local / 0.035, (1.0 - local) / 0.10)
                val f = notes[noteIndex]
                val wave = when (track) {
                    1 -> sin(2.0 * PI * f * t) * 0.038 + sin(2.0 * PI * f * 0.5 * t) * 0.012
                    2 -> sin(2.0 * PI * f * t) * 0.030 + sin(2.0 * PI * f * 1.5 * t) * 0.010
                    3 -> sin(2.0 * PI * f * t) * 0.036 + sin(2.0 * PI * f * 0.5 * t) * 0.018 +
                            sin(2.0 * PI * f * 2.0 * t) * 0.006
                    4 -> sin(2.0 * PI * f * t) * 0.034 + sin(2.0 * PI * f * 2.0 * t) * 0.016 +
                            sin(2.0 * PI * f * 3.0 * t) * 0.006
                    else -> sin(2.0 * PI * f * t) * 0.040 + sin(2.0 * PI * f * 2.0 * t) * 0.012
                }
                val s = wave * fade
                val sample = (s * Short.MAX_VALUE).toInt().coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt())
                out.write(sample and 255); out.write((sample shr 8) and 255)
            }
        }
    }

    private fun load(name: String, frequency: Double, seconds: Double, volume: Double) {
        val file = File(context.cacheDir, "$name.wav")
        if (!file.exists()) createTone(file, frequency, seconds, volume)
        ids[name] = pool.load(file.absolutePath, 1)
    }

    private fun createTone(file: File, frequency: Double, seconds: Double, volume: Double) {
        val sampleRate = 22050
        val count = (sampleRate * seconds).toInt()
        FileOutputStream(file).use { out ->
            val dataSize = count * 2
            fun le(v: Int) {
                out.write(v and 255); out.write((v shr 8) and 255)
                out.write((v shr 16) and 255); out.write((v shr 24) and 255)
            }
            out.write("RIFF".toByteArray()); le(36 + dataSize)
            out.write("WAVEfmt ".toByteArray())
            le(16); out.write(1); out.write(0); out.write(1); out.write(0)
            le(sampleRate); le(sampleRate * 2); out.write(2); out.write(0)
            out.write(16); out.write(0); out.write("data".toByteArray()); le(dataSize)
            for (i in 0 until count) {
                val t = i.toDouble() / sampleRate
                val envelope = minOf(1.0, i / (sampleRate * 0.015)) *
                        minOf(1.0, (count - i) / (sampleRate * 0.05))
                val s = sin(2.0 * PI * frequency * t) * volume * envelope
                val sample = (s * Short.MAX_VALUE).toInt().coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt())
                out.write(sample and 255); out.write((sample shr 8) and 255)
            }
        }
    }

    fun play(name: String, enabled: Boolean) {
        if (!enabled || name == "music") return
        ids[name]?.let { pool.play(it, 1f, 1f, 1, 0, 1f) }
    }

    fun setMusic(enabled: Boolean, track: Int = 0) {
        if (!enabled) {
            pauseMusic()
            return
        }
        if (musicStream != 0) pool.stop(musicStream)
        musicStream = ids["music_${track.coerceIn(0, 4)}"]?.let { id ->
            pool.play(id, 0.34f, 0.34f, 0, -1, 1f)
        } ?: 0
    }

    fun pauseMusic() {
        if (musicStream != 0) pool.pause(musicStream)
    }

    fun resumeMusic(enabled: Boolean, track: Int = 0) {
        if (enabled) {
            if (musicStream != 0) pool.resume(musicStream) else setMusic(true, track)
        }
    }

    fun release() = pool.release()
}
