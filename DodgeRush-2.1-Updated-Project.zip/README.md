# Dodge Rush

A small polished offline Android arcade game built with Kotlin and a custom Android Canvas View.

## Architecture
- Kotlin
- Android native `View` + `Canvas`
- No game engine
- No third-party runtime libraries
- `SharedPreferences` for local progress/settings
- `SoundPool` for tiny locally generated WAV effects
- Portrait-only
- Minimum Android 8.0 (API 26)
- No INTERNET permission and no analytics/ads/login/backend

## Build
1. Install Android Studio with Android SDK Platform 35 and JDK 17.
2. Open this folder in Android Studio.
3. Allow Gradle sync to finish.
4. Select `app`.
5. Build > Build Bundle(s) / APK(s) > Build APK(s).
6. APK: `app/build/outputs/apk/debug/app-debug.apk`

For a signed release APK:
Build > Generate Signed Bundle / APK > APK > Create new keystore > choose `release`.
Keep the keystore and passwords safe. A release APK can be found under `app/build/outputs/apk/release/`.

## Controls
- Touch/drag horizontally
- A / D or Left / Right arrows when testing with a keyboard
- Escape pauses when a keyboard is available

## Privacy
The manifest intentionally requests no permissions. The game does not use the internet, accounts, ads, analytics, location, contacts, camera, microphone, Firebase, or a server.

## Free cloud APK build (no Android Studio)

This project includes `.github/workflows/build-apk.yml`.

You can build the APK for free with GitHub Actions from a public GitHub repository:
1. Put the project files in a public GitHub repository.
2. Open **Actions → Build Dodge Rush APK → Run workflow**.
3. When the workflow finishes, open the run and download the **DodgeRush-APK** artifact.
4. Extract the artifact and install `app-debug.apk` on your Android phone.

The game itself does not require internet access and the Android manifest contains no permissions.


## Enhanced Edition

This revision adds an animated starfield, moving neon grid, upgraded spaceship and thruster,
multiple obstacle styles, improved coin animation, score-milestone effects, crash screen shake,
and lightweight generated background music with a working Music toggle.

## Dodge Rush 2.0

New in 2.0: six selectable ship skins, three offline generated music tracks, a skin/track selector in Settings, and persistent selections. No internet, ads, analytics, accounts, or extra permissions are required by the game.

## Dodge Rush 2.1

New in 2.1: three more ship skins — Vapor, Crimson, Aurora — for nine total (Neon, Plasma, Gold, Toxic, Ice, Sunset, Vapor, Crimson, Aurora), two more offline generated music tracks — Sunrise and Warp Drive — for five total, a redesigned main menu with a tappable skin swatch row (tap any dot to preview/select a skin instantly) plus a subtle animated glow/bob on the title and ship, and a fix for a display bug where the Sunset skin's name did not show correctly on the main menu.
