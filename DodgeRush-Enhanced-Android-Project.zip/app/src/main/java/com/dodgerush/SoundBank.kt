package com.dodgerush

import android.content.Context
import android.media.AudioAttributes
import android.media.SoundPool
import java.io.File
import java.io.FileOutputStream
import kotlin.math.PI
import kotlin.math.sin

class SoundBank(private val context: Context) {
    private val pool = SoundPool.Builder()
        .setMaxStreams(4)
        .setAudioAttributes(
            AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_GAME)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()
        )
        .build()

    private val ids = mutableMapOf<String, Int>()
    private var musicStream = 0

    init {
        load("coin", 880.0, 0.10, 0.25)
        load("button", 520.0, 0.06, 0.18)
        load("collision", 90.0, 0.18, 0.30)
        load("gameover", 180.0, 0.28, 0.28)
        load("highscore", 660.0, 0.35, 0.28)
        loadMusic()
    }

    private fun loadMusic() {
        val file = File(context.cacheDir, "music.wav")
        if (!file.exists()) createMusic(file)
        ids["music"] = pool.load(file.absolutePath, 1)
    }

    private fun createMusic(file: File) {
        val sampleRate = 22050
        val seconds = 8.0
        val count = (sampleRate * seconds).toInt()
        val notes = doubleArrayOf(220.0, 277.18, 329.63, 277.18, 196.0, 246.94, 293.66, 246.94)
        FileOutputStream(file).use { out ->
            val dataSize = count * 2
            fun le(v: Int) {
                out.write(v and 255); out.write((v shr 8) and 255)
                out.write((v shr 16) and 255); out.write((v shr 24) and 255)
            }
            out.write("RIFF".toByteArray()); le(36 + dataSize)
            out.write("WAVEfmt ".toByteArray())
            le(16); out.write(1); out.write(0); out.write(1); out.write(0)
            le(sampleRate); le(sampleRate * 2); out.write(2); out.write(0)
            out.write(16); out.write(0); out.write("data".toByteArray()); le(dataSize)
            for (i in 0 until count) {
                val t = i.toDouble() / sampleRate
                val noteIndex = (t / 0.5).toInt() % notes.size
                val local = (t % 0.5) / 0.5
                val fade = minOf(1.0, local / 0.04, (1.0 - local) / 0.08)
                val f = notes[noteIndex]
                val s = (sin(2.0 * PI * f * t) * 0.045 +
                         sin(2.0 * PI * f * 2.0 * t) * 0.012) * fade
                val sample = (s * Short.MAX_VALUE).toInt().coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt())
                out.write(sample and 255); out.write((sample shr 8) and 255)
            }
        }
    }

    private fun load(name: String, frequency: Double, seconds: Double, volume: Double) {
        val file = File(context.cacheDir, "$name.wav")
        if (!file.exists()) createTone(file, frequency, seconds, volume)
        ids[name] = pool.load(file.absolutePath, 1)
    }

    private fun createTone(file: File, frequency: Double, seconds: Double, volume: Double) {
        val sampleRate = 22050
        val count = (sampleRate * seconds).toInt()
        FileOutputStream(file).use { out ->
            val dataSize = count * 2
            fun le(v: Int) {
                out.write(v and 255); out.write((v shr 8) and 255)
                out.write((v shr 16) and 255); out.write((v shr 24) and 255)
            }
            out.write("RIFF".toByteArray()); le(36 + dataSize)
            out.write("WAVEfmt ".toByteArray())
            le(16); out.write(1); out.write(0); out.write(1); out.write(0)
            le(sampleRate); le(sampleRate * 2); out.write(2); out.write(0)
            out.write(16); out.write(0); out.write("data".toByteArray()); le(dataSize)
            for (i in 0 until count) {
                val t = i.toDouble() / sampleRate
                val envelope = minOf(1.0, i / (sampleRate * 0.015)) *
                        minOf(1.0, (count - i) / (sampleRate * 0.05))
                val s = sin(2.0 * PI * frequency * t) * volume * envelope
                val sample = (s * Short.MAX_VALUE).toInt().coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt())
                out.write(sample and 255); out.write((sample shr 8) and 255)
            }
        }
    }

    fun play(name: String, enabled: Boolean) {
        if (!enabled || name == "music") return
        ids[name]?.let { pool.play(it, 1f, 1f, 1, 0, 1f) }
    }

    fun setMusic(enabled: Boolean) {
        if (!enabled) {
            pauseMusic()
            return
        }
        if (musicStream == 0) {
            ids["music"]?.let { id ->
                musicStream = pool.play(id, 0.34f, 0.34f, 0, -1, 1f)
            }
        } else {
            pool.resume(musicStream)
        }
    }

    fun pauseMusic() {
        if (musicStream != 0) pool.pause(musicStream)
    }

    fun resumeMusic(enabled: Boolean) {
        if (enabled) setMusic(true)
    }

    fun release() = pool.release()
}
