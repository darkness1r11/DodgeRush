package com.dodgerush

import android.content.Context
import android.graphics.*
import android.os.SystemClock
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.random.Random

class DodgeRushView(context: Context) : View(context) {
    private enum class Screen { MENU, HOW_TO, SHOP, SETTINGS, GAME, PAUSE, GAME_OVER }

    private data class Obstacle(
        var x: Float, var y: Float, var w: Float, var h: Float,
        var speed: Float, var rotation: Float, var spin: Float, var kind: Int,
        var grazed: Boolean = false
    )

    private data class Coin(var x: Float, var y: Float, var r: Float, var speed: Float, var phase: Float)
    private data class Power(var x: Float, var y: Float, var r: Float, var speed: Float, var type: Int, var phase: Float)
    private data class Bullet(var x: Float, var y: Float, var speed: Float, var damage: Int, var fromPlayer: Boolean)
    private data class Particle(var x: Float, var y: Float, var vx: Float, var vy: Float, var life: Float, var size: Float, var hue: Int)
    private data class Star(var x: Float, var y: Float, var size: Float, var speed: Float, var alpha: Int)

    private val prefs = GamePrefs(context)
    private val sound = SoundBank(context)
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val glow = Paint(Paint.ANTI_ALIAS_FLAG)
    private val random = Random(System.currentTimeMillis())

    private var screen = Screen.MENU
    private var pausedBySystem = false
    private var lastFrame = 0L

    private var playerX = 0.5f
    private var playerTarget = 0.5f
    private var elapsed = 0f
    private var score = 0L
    private var runCoins = 0L
    private var combo = 0
    private var comboTimer = 0f
    private var level = 1
    private var levelFlash = 0f

    private var spawnTimer = 0f
    private var coinTimer = 0f
    private var powerTimer = 0f
    private var fireTimer = 0f
    private var bossNextAt = 45f
    private var bossActive = false
    private var bossType = 0
    private var bossX = 0.5f
    private var bossY = -0.2f
    private var bossHp = 0
    private var bossMaxHp = 0
    private var bossShotTimer = 0f
    private var bossPhase = 0f
    private var bossWarned = false
    private var bossFlash = 0f

    private var shieldCharges = 0
    private var slowTimer = 0f
    private var magnetTimer = 0f
    private var overdriveTimer = 0f
    private var invulnTimer = 0f

    private var newHigh = false
    private var gridOffset = 0f
    private var screenShake = 0f
    private var flash = 0f
    private var selectedShopIndex = 0

    private val obstacles = mutableListOf<Obstacle>()
    private val coins = mutableListOf<Coin>()
    private val powers = mutableListOf<Power>()
    private val bullets = mutableListOf<Bullet>()
    private val particles = mutableListOf<Particle>()
    private val stars = mutableListOf<Star>()

    private val skinColors = intArrayOf(
        Color.rgb(108,255,234),
        Color.rgb(132,112,255),
        Color.rgb(255,214,82),
        Color.rgb(114,255,104),
        Color.rgb(106,209,255),
        Color.rgb(255,103,173),
        Color.rgb(190,110,255)
    )
    private val skinAccent = intArrayOf(
        Color.rgb(255,92,154),
        Color.rgb(255,92,210),
        Color.rgb(255,153,50),
        Color.rgb(217,255,77),
        Color.rgb(224,248,255),
        Color.rgb(255,214,82),
        Color.rgb(79,120,255)
    )
    private val skinNames = arrayOf("NEON","PLASMA","GOLD","TOXIC","ICE","SUNSET","VOID")
    private val skinCosts = intArrayOf(0, 180, 420, 700, 1100, 1700, 2600)
    private val musicNames = arrayOf("Neon Run","Pulse Reactor","Night Drive","Velocity","Boss Protocol")

    init {
        isFocusable = true
        isClickable = true
        requestFocus()
        sound.normalMusic(prefs.music, prefs.musicTrack)
        lastFrame = SystemClock.uptimeMillis()
        postInvalidateOnAnimation()
    }

    private fun W() = width.toFloat()
    private fun H() = height.toFloat()

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        onNewFrame()
        drawBackground(c)
        when (screen) {
            Screen.MENU -> drawMenu(c)
            Screen.HOW_TO -> drawHowTo(c)
            Screen.SHOP -> drawShop(c)
            Screen.SETTINGS -> drawSettings(c)
            Screen.GAME -> drawGame(c)
            Screen.PAUSE -> { drawGame(c); drawOverlayPanel(c, "PAUSED", "RESUME", "RESTART", "MENU") }
            Screen.GAME_OVER -> drawGameOver(c)
        }
        if (flash > 0f) {
            paint.color = Color.argb((90f * flash).toInt().coerceIn(0,90), 255,255,255)
            c.drawRect(0f,0f,W(),H(),paint)
        }
        postInvalidateOnAnimation()
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val x = e.x
        val y = e.y
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                if (screen == Screen.GAME) {
                    playerTarget = (x / W()).coerceIn(0.08f, 0.92f)
                    return true
                }
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                if (screen == Screen.GAME) {
                    playerTarget = (x / W()).coerceIn(0.08f, 0.92f)
                    return true
                }
            }
            MotionEvent.ACTION_UP -> {
                handleTap(x, y)
                return true
            }
        }
        return true
    }

    private fun handleTap(x: Float, y: Float) {
        when (screen) {
            Screen.MENU -> {
                when {
                    hit(x,y,W()/2f,H()*0.48f,W()*0.60f,H()*0.09f) -> startGame()
                    hit(x,y,W()/2f,H()*0.60f,W()*0.60f,H()*0.07f) -> { screen=Screen.SHOP; button() }
                    hit(x,y,W()/2f,H()*0.69f,W()*0.60f,H()*0.07f) -> { screen=Screen.HOW_TO; button() }
                    hit(x,y,W()/2f,H()*0.78f,W()*0.60f,H()*0.07f) -> { screen=Screen.SETTINGS; button() }
                }
            }
            Screen.HOW_TO -> {
                if (hit(x,y,W()/2f,H()*0.88f,W()*0.56f,H()*0.08f)) { screen=Screen.MENU; button() }
            }
            Screen.SHOP -> handleShopTap(x,y)
            Screen.SETTINGS -> handleSettingsTap(x,y)
            Screen.GAME -> {
                if (hit(x,y,W()*0.90f,H()*0.055f,W()*0.13f,H()*0.07f)) {
                    screen = Screen.PAUSE
                    sound.pauseMusic()
                    button()
                }
            }
            Screen.PAUSE -> {
                val cy = H()*0.48f
                when {
                    hit(x,y,W()/2f,cy,W()*0.55f,H()*0.08f) -> { screen=Screen.GAME; sound.resumeMusic(prefs.music, prefs.musicTrack); button() }
                    hit(x,y,W()/2f,cy+H()*0.11f,W()*0.55f,H()*0.08f) -> { startGame(); }
                    hit(x,y,W()/2f,cy+H()*0.22f,W()*0.55f,H()*0.08f) -> { screen=Screen.MENU; sound.normalMusic(prefs.music, prefs.musicTrack); button() }
                }
            }
            Screen.GAME_OVER -> {
                if (hit(x,y,W()/2f,H()*0.68f,W()*0.58f,H()*0.08f)) startGame()
                else if (hit(x,y,W()/2f,H()*0.79f,W()*0.58f,H()*0.08f)) { screen=Screen.MENU; sound.normalMusic(prefs.music,prefs.musicTrack); button() }
            }
        }
    }

    private fun handleSettingsTap(x: Float, y: Float) {
        when {
            hit(x,y,W()/2f,H()*0.35f,W()*0.78f,H()*0.07f) -> { prefs.sound=!prefs.sound; button() }
            hit(x,y,W()/2f,H()*0.45f,W()*0.78f,H()*0.07f) -> { prefs.music=!prefs.music; sound.setMusic(prefs.music,prefs.musicTrack); button() }
            hit(x,y,W()/2f,H()*0.55f,W()*0.78f,H()*0.07f) -> { prefs.vibration=!prefs.vibration; button() }
            hit(x,y,W()/2f,H()*0.66f,W()*0.78f,H()*0.07f) -> {
                prefs.musicTrack = (prefs.musicTrack + 1) % 4
                sound.normalMusic(prefs.music,prefs.musicTrack); button()
            }
            hit(x,y,W()/2f,H()*0.84f,W()*0.56f,H()*0.08f) -> { screen=Screen.MENU; button() }
        }
    }

    private fun handleShopTap(x: Float, y: Float) {
        if (hit(x,y,W()/2f,H()*0.24f,W()*0.75f,H()*0.08f)) {
            selectedShopIndex = (selectedShopIndex + 1) % skinNames.size
            button()
            return
        }
        if (hit(x,y,W()/2f,H()*0.50f,W()*0.72f,H()*0.08f)) {
            val i = selectedShopIndex
            if (prefs.ownsSkin(i)) {
                prefs.selectedSkin = i
                button()
            } else if (prefs.totalCoins >= skinCosts[i]) {
                prefs.totalCoins -= skinCosts[i].toLong()
                prefs.unlockSkin(i)
                prefs.selectedSkin = i
                sound.play("power", prefs.sound)
                vibrate(HapticFeedbackConstants.CONFIRM)
            } else {
                sound.play("hit", prefs.sound)
                vibrate(HapticFeedbackConstants.REJECT)
            }
            return
        }
        val upgradeY = H()*0.63f
        val rows = arrayOf("BLASTER","MAGNET","SHIELD","CHRONO")
        if (y in upgradeY-H()*0.03f..upgradeY+H()*0.36f) {
            val row = ((y - upgradeY) / (H()*0.085f)).toInt()
            if (row in 0..3) {
                buyUpgrade(row)
                return
            }
        }
        if (hit(x,y,W()/2f,H()*0.92f,W()*0.56f,H()*0.07f)) {
            screen=Screen.MENU; button()
        }
    }

    private fun buyUpgrade(row: Int) {
        val level = when(row) {
            0 -> prefs.blasterLevel
            1 -> prefs.magnetLevel
            2 -> prefs.shieldLevel
            else -> prefs.chronoLevel
        }
        val maxLevel = when(row) { 0 -> 8; 1 -> 6; 2 -> 5; else -> 6 }
        if (level >= maxLevel) { sound.play("hit",prefs.sound); return }
        val base = when(row) { 0 -> 140; 1 -> 110; 2 -> 180; else -> 150 }
        val cost = prefs.upgradeCost(level, base)
        if (prefs.totalCoins >= cost) {
            prefs.totalCoins -= cost.toLong()
            when(row) {
                0 -> prefs.blasterLevel = level+1
                1 -> prefs.magnetLevel = level+1
                2 -> prefs.shieldLevel = level+1
                else -> prefs.chronoLevel = level+1
            }
            sound.play("power", prefs.sound)
            vibrate(HapticFeedbackConstants.CONFIRM)
        } else {
            sound.play("hit",prefs.sound)
        }
    }

    private fun startGame() {
        screen = Screen.GAME
        playerX = 0.5f
        playerTarget = 0.5f
        elapsed = 0f
        score = 0L
        runCoins = 0L
        combo = 0
        comboTimer = 0f
        level = 1
        spawnTimer = 0f
        coinTimer = 0.7f
        powerTimer = 3.2f
        fireTimer = 0f
        bossNextAt = 45f
        bossActive = false
        bossWarned = false
        bossPhase = 0f
        bossHp = 0
        shieldCharges = prefs.shieldLevel
        slowTimer = 0f
        magnetTimer = 0f
        overdriveTimer = 0f
        invulnTimer = 0f
        obstacles.clear(); coins.clear(); powers.clear(); bullets.clear(); particles.clear()
        milestoneParticles(0,0)
        sound.normalMusic(prefs.music,prefs.musicTrack)
        button()
    }

    private fun update(dtRaw: Float) {
        if (screen != Screen.GAME || pausedBySystem) return
        val dt = dtRaw.coerceAtMost(0.033f)
        val timeScale = if (slowTimer > 0f) 0.52f else 1f
        val dtScaled = dt * timeScale

        elapsed += dt
        score = (elapsed * 12f * (1f + elapsed/70f)).toLong() + combo * 4L
        level = 1 + (elapsed / 18f).toInt()
        levelFlash = max(0f, levelFlash - dt)
        playerX += (playerTarget-playerX) * min(1f, dt*12f)

        comboTimer = max(0f,comboTimer-dt)
        if(comboTimer<=0f) combo=0

        if (slowTimer > 0f) slowTimer -= dt
        if (magnetTimer > 0f) magnetTimer -= dt
        if (overdriveTimer > 0f) overdriveTimer -= dt
        if (invulnTimer > 0f) invulnTimer -= dt
        if (screenShake > 0f) screenShake -= dt
        if (flash > 0f) flash -= dt
        bossFlash = max(0f,bossFlash-dt)

        gridOffset = (gridOffset + H()*0.16f*dtScaled) % (H()*0.09f)
        ensureStars()
        for (s in stars) {
            s.y += s.speed * dtScaled
            if (s.y>H()+5f) { s.y=-5f; s.x=random.nextFloat() }
        }

        spawnTimer += dtScaled
        coinTimer += dtScaled
        powerTimer += dtScaled
        fireTimer += dtScaled

        val difficulty = 1f + elapsed/28f
        val spawnEvery = max(0.25f,0.70f - difficulty*0.026f)
        if (spawnTimer >= spawnEvery && !bossActive) {
            spawnTimer=0f
            spawnPattern(difficulty)
        }
        if (coinTimer >= 0.62f) {
            coinTimer=0f
            spawnCoin()
        }
        if (powerTimer >= 7.5f && !bossActive) {
            powerTimer=0f
            if(random.nextFloat()<0.78f) spawnPower()
        }

        if (!bossActive && elapsed >= bossNextAt) spawnBoss()
        if (!bossActive && !bossWarned && bossNextAt-elapsed in 0.0f..4.0f) {
            bossWarned=true
            sound.play("warning",prefs.sound)
            vibrate(HapticFeedbackConstants.LONG_PRESS)
        }

        val moveSpeed = H()*(0.22f + min(0.20f,difficulty*0.017f))
        for(o in obstacles) {
            o.y += o.speed*dtScaled
            o.rotation += o.spin*dtScaled
        }
        for(cn in coins) {
            cn.y += cn.speed*dtScaled
            cn.phase += dt*7f
            if(magnetTimer>0f) {
                val px=playerX*W()
                val cx=cn.x*W()
                val dx=px-cx
                val radius=W()*(0.20f+prefs.magnetLevel*0.045f)
                if(abs(dx)<radius && abs(cn.y-H()*0.84f)<H()*0.25f) {
                    cn.x += (dx/W())*dt*3.8f
                    cn.y += (H()*0.84f-cn.y)*dt*2.6f
                }
            }
        }
        for(p in powers) { p.y += p.speed*dtScaled; p.phase += dt*5f }
        for(b in bullets) {
            b.y += (if(b.fromPlayer) -b.speed else b.speed)*dtScaled
        }
        updateParticles(dt)

        checkCollisions()
        cull()

        if (bossActive) updateBoss(dt,dtScaled)

        if (level > 1 && (levelFlash<=0f) && ((elapsed-dt).toInt()/18 < (elapsed/18f).toInt())) {
            levelFlash=0.8f
            burst(W()/2f,H()*0.17f,14,skinColors[prefs.selectedSkin],2f)
            sound.play("power",prefs.sound)
        }
    }

    private fun spawnPattern(d: Float) {
        val count = 1 + if(random.nextFloat()<min(0.42f,d*0.08f)) 1 else 0
        if(count==1) {
            addObstacle(random.nextDouble(0.06,0.84).toFloat(),H()*(0.18f+d*0.012f),0.16f+random.nextFloat()*0.05f,random.nextInt(4))
        } else {
            val gapCenter=random.nextDouble(0.30,0.70).toFloat()
            addObstacle(gapCenter-0.30f,H()*(0.17f+d*0.010f),0.17f,random.nextInt(4))
            addObstacle(gapCenter+0.17f,H()*(0.20f+d*0.010f),0.17f,random.nextInt(4))
        }
        if(random.nextFloat()<0.16f+d*0.01f) {
            addObstacle(random.nextDouble(0.08,0.84).toFloat(),H()*(0.24f+d*0.012f),0.11f,4)
        }
    }

    private fun addObstacle(nx:Float,speed:Float,widthNorm:Float,kind:Int) {
        val w=W()*widthNorm
        obstacles += Obstacle(
            x=(nx.coerceIn(0.03f,0.97f-widthNorm))*W(),
            y=-H()*0.10f,
            w=w,
            h=w*random.nextDouble(0.65,1.05).toFloat(),
            speed=speed*random.nextDouble(0.82,1.13).toFloat(),
            rotation=random.nextFloat()*360f,
            spin=random.nextDouble(-80.0,80.0).toFloat(),
            kind=kind
        )
    }

    private fun spawnCoin() {
        coins += Coin(
            x=random.nextDouble(0.08,0.92).toFloat(),
            y=-W()*0.08f,
            r=max(8f,W()*0.018f),
            speed=H()*random.nextDouble(0.15,0.22).toFloat(),
            phase=random.nextFloat()*6.28f
        )
    }

    private fun spawnPower() {
        powers += Power(
            x=random.nextDouble(0.10,0.90).toFloat(),
            y=-W()*0.10f,
            r=max(12f,W()*0.025f),
            speed=H()*0.13f,
            type=random.nextInt(4),
            phase=random.nextFloat()*6.28f
        )
    }

    private fun spawnBoss() {
        bossActive=true
        bossType=(prefs.bossesDefeated+level)%3
        bossX=0.5f
        bossY=-0.18f
        bossMaxHp=38+level*8+bossType*10
        bossHp=bossMaxHp
        bossShotTimer=0.8f
        bossPhase=0f
        bossFlash=0f
        bossWarned=true
        bullets.clear()
        obstacles.clear()
        sound.bossMusic(prefs.music)
        vibrate(HapticFeedbackConstants.LONG_PRESS)
        burst(W()/2f,H()*0.12f,28,Color.rgb(255,75,120),3f)
    }

    private fun updateBoss(dt:Float,scaled:Float) {
        bossPhase += dt
        bossY += (H()*0.13f-bossY)*min(1f,dt*1.6f)
        val wave=when(bossType){0->0.21f;1->0.32f;else->0.28f}
        bossX=0.5f+kotlin.math.sin(bossPhase*wave*9f).toFloat()*0.34f

        bossShotTimer-=scaled
        if(bossShotTimer<=0f) {
            bossShotTimer=max(0.27f,0.62f-level*0.012f)
            val patterns=when(bossType) {
                0 -> 1
                1 -> 3
                else -> 5
            }
            repeat(patterns) { idx ->
                val spread=(idx-(patterns-1)/2f)*0.07f
                bullets += Bullet(
                    x=(bossX+spread).coerceIn(0.03f,0.97f),
                    y=bossY+H()*0.07f,
                    speed=H()*(0.30f+level*0.012f),
                    damage=1,
                    fromPlayer=false
                )
            }
            sound.play("shoot",prefs.sound)
        }

        if(fireTimer >= if(overdriveTimer>0f) 0.13f else 0.25f) {
            fireTimer=0f
            bullets += Bullet(playerX,H()*0.80f,H()*0.72f,1+prefs.blasterLevel/3,true)
            sound.play("shoot",prefs.sound)
        }

        val px=playerX*W()
        val py=H()*0.84f
        val br=W()*0.055f
        if(circleHit(px,py,bossX*W(),bossY+H()*0.02f,br*0.9f) && invulnTimer<=0f) {
            hurt()
        }

        for (b in bullets.toList()) {
            if(b.fromPlayer) {
                val bx=b.x*W()
                val by=b.y
                if(bx in bossX*W()-W()*0.12f..bossX*W()+W()*0.12f && by in bossY-H()*0.02f..bossY+H()*0.15f) {
                    bossHp-=b.damage
                    bullets.remove(b)
                    bossFlash=0.08f
                    burst(bx,by,3,skinColors[prefs.selectedSkin],1.4f)
                    if(bossHp<=0) {
                        defeatBoss()
                        break
                    }
                }
            } else {
                if(circleHit(px,py,b.x*W(),b.y,W()*0.032f+W()*0.028f)) {
                    bullets.remove(b)
                    if(invulnTimer<=0f) hurt()
                }
            }
        }
    }

    private fun defeatBoss() {
        bossActive=false
        val reward=100L+level*30L
        runCoins+=reward
        prefs.totalCoins+=reward
        score+=3000L+level*500L
        prefs.bossesDefeated=prefs.bossesDefeated+1
        bossNextAt=elapsed+52f
        bossWarned=false
        bossHp=0
        bullets.clear()
        burst(bossX*W(),bossY,70,Color.rgb(255,214,82),4f)
        screenShake=0.5f
        flash=1f
        sound.play("bossdown",prefs.sound)
        sound.normalMusic(prefs.music,prefs.musicTrack)
        vibrate(HapticFeedbackConstants.CONFIRM)
    }

    private fun checkCollisions() {
        val px=playerX*W()
        val py=H()*0.84f
        val pr=W()*0.035f

        for(o in obstacles.toList()) {
            if(rectCircle(o.x,o.y,o.w,o.h,px,py,pr*0.88f)) {
                if(invulnTimer<=0f) {
                    if(shieldCharges>0) {
                        shieldCharges--
                        invulnTimer=1.0f
                        screenShake=0.22f
                        burst(px,py,25,Color.rgb(108,255,234),2.5f)
                        sound.play("power",prefs.sound)
                        vibrate(HapticFeedbackConstants.CONTEXT_CLICK)
                        obstacles.remove(o)
                    } else {
                        crash()
                        return
                    }
                }
            } else if(!o.grazed && o.y+o.h > py-pr*2.5f && o.y < py+pr*2.5f) {
                val ox = if(px < o.x) o.x else o.x+o.w
                val gap=abs(px-ox)
                if(gap < W()*0.11f && gap > pr*1.15f) {
                    o.grazed=true
                    combo=min(99,combo+1)
                    comboTimer=2.2f
                    score+=25L*combo
                    burst(px,py,5,Color.rgb(255,214,82),1.5f)
                }
            }
        }

        for(cn in coins.toList()) {
            val cx=cn.x*W()
            if(circleHit(px,py,cx,cn.y,pr+cn.r)) {
                coins.remove(cn)
                runCoins++
                prefs.totalCoins++
                score+=12L+combo*2L
                burst(cx,cn.y,9,Color.rgb(255,214,82),1.4f)
                sound.play("coin",prefs.sound)
                vibrate(HapticFeedbackConstants.CLOCK_TICK)
            }
        }

        for(p in powers.toList()) {
            if(circleHit(px,py,p.x*W(),p.y,pr+p.r)) {
                powers.remove(p)
                applyPower(p.type)
                burst(p.x*W(),p.y,16,powerColor(p.type),2f)
                sound.play("power",prefs.sound)
                vibrate(HapticFeedbackConstants.CONFIRM)
            }
        }
    }

    private fun applyPower(type:Int) {
        when(type) {
            0 -> shieldCharges=min(4,shieldCharges+1)
            1 -> slowTimer=5.0f+prefs.chronoLevel*0.8f
            2 -> magnetTimer=7.0f+prefs.magnetLevel*1.1f
            else -> overdriveTimer=4.5f+prefs.blasterLevel*0.45f
        }
        score+=100
    }

    private fun hurt() {
        if(invulnTimer>0f) return
        if(shieldCharges>0) {
            shieldCharges--
            invulnTimer=1f
            burst(playerX*W(),H()*0.84f,25,Color.rgb(108,255,234),2.3f)
            sound.play("power",prefs.sound)
            vibrate(HapticFeedbackConstants.CONTEXT_CLICK)
        } else crash()
    }

    private fun crash() {
        newHigh=score>prefs.highScore
        if(newHigh) prefs.highScore=score
        if(elapsed>prefs.bestTime) prefs.bestTime=elapsed
        burst(playerX*W(),H()*0.84f,55,skinAccent[prefs.selectedSkin],3.5f)
        screenShake=0.5f
        flash=1f
        sound.play("gameover",prefs.sound)
        sound.pauseMusic()
        screen=Screen.GAME_OVER
        vibrate(HapticFeedbackConstants.LONG_PRESS)
    }

    private fun cull() {
        obstacles.removeAll { it.y>H()+H()*0.18f }
        coins.removeAll { it.y>H()+W()*0.2f }
        powers.removeAll { it.y>H()+W()*0.2f }
        bullets.removeAll { it.y<-H()*0.08f || it.y>H()*1.1f }
    }

    private fun updateParticles(dt:Float) {
        val it=particles.iterator()
        while(it.hasNext()) {
            val p=it.next()
            p.x+=p.vx*dt
            p.y+=p.vy*dt
            p.life-=dt
            p.vy+=H()*0.15f*dt
            if(p.life<=0f) it.remove()
        }
    }

    private fun burst(x:Float,y:Float,n:Int,color:Int,sizeMul:Float=1f) {
        repeat(n) {
            val a=random.nextFloat()*6.283f
            val speed=random.nextDouble(35.0,220.0).toFloat()
            particles+=Particle(x,y,kotlin.math.cos(a)*speed,kotlin.math.sin(a)*speed,random.nextDouble(0.25,0.7).toFloat(),random.nextDouble(2.0,6.5).toFloat()*sizeMul,color)
        }
    }

    private fun milestoneParticles(x:Float,y:Float) { }

    private fun ensureStars() {
        while(stars.size<45) {
            stars+=Star(random.nextFloat(),random.nextFloat()*H(),random.nextDouble(0.7,2.2).toFloat(),H()*random.nextDouble(0.008,0.03).toFloat(),random.nextInt(35,130))
        }
    }

    private fun drawBackground(c:Canvas) {
        paint.shader=LinearGradient(0f,0f,0f,H(),Color.rgb(10,19,42),Color.rgb(2,5,12),Shader.TileMode.CLAMP)
        c.drawRect(0f,0f,W(),H(),paint)
        paint.shader=null

        ensureStars()
        stars.forEach {
            paint.color=Color.argb(it.alpha,170,220,255)
            c.drawCircle(it.x*W(),it.y,it.size,paint)
        }

        paint.color=Color.argb(22,108,255,234)
        for(i in 0..7) {
            val y=H()*0.45f+i*H()*0.065f+gridOffset
            c.drawRect(0f,y,W(),y+1.5f,paint)
        }
        for(i in -5..5) {
            val x=W()/2f+i*W()*0.13f
            c.drawRect(x,H()*0.45f,x+1f,H(),paint)
        }

        paint.color=Color.argb(16,255,90,150)
        c.drawCircle(W()*0.18f,H()*0.18f,W()*0.24f,paint)
        c.drawCircle(W()*0.84f,H()*0.30f,W()*0.30f,paint)
    }

    private fun drawMenu(c:Canvas) {
        drawTitle(c,H()*0.18f)
        drawDecorativeShip(c,W()/2f,H()*0.31f)
        text(c,"SCORE. SURVIVE. DESTROY.",W()/2f,H()*0.40f,W()*0.031f,Color.rgb(160,200,220),Paint.Align.CENTER,false)

        button(c,"PLAY",W()/2f,H()*0.50f,W()*0.60f,H()*0.085f,true)
        button(c,"SHOP",W()/2f,H()*0.61f,W()*0.60f,H()*0.07f)
        button(c,"HOW TO PLAY",W()/2f,H()*0.70f,W()*0.60f,H()*0.07f)
        button(c,"SETTINGS",W()/2f,H()*0.79f,W()*0.60f,H()*0.07f)

        text(c,"COINS  ${prefs.totalCoins}",W()/2f,H()*0.90f,W()*0.031f,Color.rgb(255,214,82),Paint.Align.CENTER,true)
        text(c,"HIGH SCORE  ${prefs.highScore}",W()/2f,H()*0.945f,W()*0.025f,Color.WHITE,Paint.Align.CENTER,false)
    }

    private fun drawTitle(c:Canvas,y:Float) {
        text(c,"DODGE",W()/2f,y,W()*0.085f,Color.rgb(108,255,234),Paint.Align.CENTER,true)
        text(c,"RUSH",W()/2f,y+H()*0.085f,W()*0.085f,Color.rgb(255,90,150),Paint.Align.CENTER,true)
    }

    private fun drawDecorativeShip(c:Canvas,px:Float,py:Float) {
        val r=min(W(),H())*0.032f
        glow.color=Color.argb(100,108,255,234)
        c.drawCircle(px,py,r*2.4f,glow)
        val main=skinColors[prefs.selectedSkin]
        paint.color=main
        val p=Path()
        p.moveTo(px,py-r*1.5f); p.lineTo(px-r*1.2f,py+r); p.lineTo(px,py+r*0.48f); p.lineTo(px+r*1.2f,py+r); p.close()
        c.drawPath(p,paint)
        paint.color=skinAccent[prefs.selectedSkin]
        c.drawCircle(px,py-r*0.35f,r*0.28f,paint)
        paint.color=Color.argb(230,255,120,150)
        c.drawOval(px-r*0.24f,py+r*0.65f,px+r*0.24f,py+r*1.7f,paint)
    }

    private fun drawGame(c:Canvas) {
        c.save()
        if(screenShake>0f) {
            val amt=9f*(screenShake/0.5f)
            c.translate(random.nextFloat()*amt-amt/2f,random.nextFloat()*amt-amt/2f)
        }

        text(c,"SCORE ${score}",W()*0.05f,H()*0.055f,W()*0.039f,Color.WHITE,Paint.Align.LEFT,true)
        text(c,"● ${runCoins}",W()*0.46f,H()*0.055f,W()*0.039f,Color.rgb(255,214,82),Paint.Align.LEFT,true)
        text(c,"LV ${level}",W()*0.05f,H()*0.092f,W()*0.028f,Color.rgb(108,255,234),Paint.Align.LEFT,true)
        if(combo>=2) text(c,"COMBO x${combo}",W()*0.48f,H()*0.092f,W()*0.030f,Color.rgb(255,90,150),Paint.Align.LEFT,true)
        button(c,"Ⅱ",W()*0.90f,H()*0.055f,W()*0.13f,H()*0.065f)

        drawPlayer(c)
        drawObjects(c)

        if(shieldCharges>0) {
            paint.style=Paint.Style.STROKE
            paint.strokeWidth=max(2f,W()*0.007f)
            paint.color=Color.argb(170,108,255,234)
            c.drawCircle(playerX*W(),H()*0.84f,W()*0.055f,paint)
            paint.style=Paint.Style.FILL
        }

        val activePower = when {
            overdriveTimer>0f -> "OVERDRIVE ${overdriveTimer.toInt()+1}"
            magnetTimer>0f -> "MAGNET ${magnetTimer.toInt()+1}"
            slowTimer>0f -> "TIME ${slowTimer.toInt()+1}"
            else -> ""
        }
        if(activePower.isNotEmpty()) text(c,activePower,W()/2f,H()*0.965f,W()*0.028f,powerColor(if(overdriveTimer>0f)3 else if(magnetTimer>0f)2 else 1),Paint.Align.CENTER,true)

        if(levelFlash>0f) text(c,"LEVEL ${level}",W()/2f,H()*0.17f,W()*0.052f,Color.argb((220*levelFlash).toInt().coerceIn(0,220),108,255,234),Paint.Align.CENTER,true)

        if(!bossActive && bossNextAt-elapsed in 0.0f..4.0f) {
            paint.color=Color.argb((90*(4f-(bossNextAt-elapsed))).toInt().coerceIn(0,90),255,40,80)
            c.drawRect(0f,0f,W(),H(),paint)
            text(c,"WARNING",W()/2f,H()*0.28f,W()*0.073f,Color.rgb(255,75,120),Paint.Align.CENTER,true)
            text(c,"BOSS IN ${(bossNextAt-elapsed).toInt()+1}",W()/2f,H()*0.34f,W()*0.032f,Color.WHITE,Paint.Align.CENTER,true)
        }

        if(bossActive) drawBossHud(c)
        c.restore()
    }

    private fun drawPlayer(c:Canvas) {
        val px=playerX*W()
        val py=H()*0.84f
        val r=min(W(),H())*0.034f
        val pulse=0.78f+0.24f*kotlin.math.sin(elapsed*19f)
        glow.color=Color.argb((90+60*pulse).toInt(),Color.red(skinColors[prefs.selectedSkin]),Color.green(skinColors[prefs.selectedSkin]),Color.blue(skinColors[prefs.selectedSkin]))
        c.drawCircle(px,py,r*1.9f,glow)

        paint.color=skinAccent[prefs.selectedSkin]
        val flame=Path()
        flame.moveTo(px,py+r*0.45f)
        flame.lineTo(px-r*0.40f,py+r*(1.6f+pulse))
        flame.lineTo(px,py+r*1.15f)
        flame.lineTo(px+r*0.40f,py+r*(1.6f+pulse))
        flame.close()
        c.drawPath(flame,paint)

        paint.color=skinColors[prefs.selectedSkin]
        val ship=Path()
        ship.moveTo(px,py-r*1.45f)
        ship.lineTo(px-r*1.08f,py+r*0.9f)
        ship.lineTo(px-r*0.38f,py+r*0.48f)
        ship.lineTo(px,py+r*0.72f)
        ship.lineTo(px+r*0.38f,py+r*0.48f)
        ship.lineTo(px+r*1.08f,py+r*0.9f)
        ship.close()
        c.drawPath(ship,paint)
        paint.style=Paint.Style.STROKE
        paint.strokeWidth=max(2f,r*0.09f)
        paint.color=Color.WHITE
        c.drawPath(ship,paint)
        paint.style=Paint.Style.FILL
        paint.color=Color.rgb(10,28,42)
        c.drawCircle(px,py-r*0.28f,r*0.30f,paint)
    }

    private fun drawObjects(c:Canvas) {
        for(o in obstacles) {
            val cx=o.x+o.w/2f
            val cy=o.y+o.h/2f
            val main=when(o.kind){0->Color.rgb(255,78,120);1->Color.rgb(255,170,72);2->Color.rgb(184,88,255);3->Color.rgb(75,220,255);else->Color.rgb(255,215,80)}
            glow.color=Color.argb(65,Color.red(main),Color.green(main),Color.blue(main))
            c.drawCircle(cx,cy,min(o.w,o.h)*0.75f,glow)
            c.save()
            c.rotate(o.rotation,cx,cy)
            paint.color=main
            if(o.kind==4) {
                val spike=Path()
                spike.moveTo(cx, o.y)
                spike.lineTo(o.x+o.w,o.y+o.h)
                spike.lineTo(o.x,o.y+o.h)
                spike.close()
                c.drawPath(spike,paint)
            } else {
                c.drawRoundRect(o.x,o.y,o.x+o.w,o.y+o.h,o.w*0.17f,o.w*0.17f,paint)
                paint.color=Color.argb(150,10,10,25)
                c.drawCircle(cx,cy,min(o.w,o.h)*0.20f,paint)
            }
            c.restore()
        }

        for(cn in coins) {
            val cx=cn.x*W()
            val pulse=1f+0.10f*kotlin.math.sin(cn.phase)
            glow.color=Color.argb(95,255,214,82)
            c.drawCircle(cx,cn.y,cn.r*1.8f,glow)
            paint.color=Color.rgb(255,214,82)
            c.drawCircle(cx,cn.y,cn.r*pulse,paint)
            paint.style=Paint.Style.STROKE
            paint.strokeWidth=max(2f,cn.r*0.10f)
            paint.color=Color.WHITE
            c.drawCircle(cx,cn.y,cn.r*0.68f,paint)
            paint.style=Paint.Style.FILL
        }

        for(p in powers) {
            val color=powerColor(p.type)
            glow.color=Color.argb(90,Color.red(color),Color.green(color),Color.blue(color))
            c.drawCircle(p.x*W(),p.y,p.r*1.7f,glow)
            paint.color=color
            c.drawCircle(p.x*W(),p.y,p.r*(1f+0.08f*kotlin.math.sin(p.phase)),paint)
            text(c,powerLetter(p.type),p.x*W(),p.y+p.r*0.42f,p.r*1.0f,Color.rgb(8,13,25),Paint.Align.CENTER,true)
        }

        for(b in bullets) {
            val col=if(b.fromPlayer) skinColors[prefs.selectedSkin] else Color.rgb(255,72,110)
            glow.color=Color.argb(100,Color.red(col),Color.green(col),Color.blue(col))
            c.drawCircle(b.x*W(),b.y,W()*0.024f,glow)
            paint.color=col
            c.drawCircle(b.x*W(),b.y,W()*0.010f,paint)
        }

        for(p in particles) {
            paint.color=p.hue
            paint.alpha=(255*(p.life/0.7f)).toInt().coerceIn(0,255)
            c.drawCircle(p.x,p.y,p.size,paint)
        }
        paint.alpha=255
    }

    private fun drawBossHud(c:Canvas) {
        val bossColor=when(bossType){0->Color.rgb(255,75,120);1->Color.rgb(183,95,255);else->Color.rgb(255,172,78)}
        glow.color=Color.argb(95,Color.red(bossColor),Color.green(bossColor),Color.blue(bossColor))
        c.drawCircle(bossX*W(),bossY,W()*0.17f,glow)
        c.save()
        c.rotate(kotlin.math.sin(bossPhase*2.1f).toFloat()*7f,bossX*W(),bossY)
        paint.color=bossColor
        c.drawCircle(bossX*W(),bossY,W()*0.095f,paint)
        paint.color=Color.rgb(18,8,25)
        c.drawCircle(bossX*W(),bossY,W()*0.044f,paint)
        paint.color=Color.WHITE
        c.drawCircle(bossX*W()-W()*0.025f,bossY-H()*0.005f,W()*0.012f,paint)
        c.drawCircle(bossX*W()+W()*0.025f,bossY-H()*0.005f,W()*0.012f,paint)
        c.restore()

        text(c,"BOSS  ${when(bossType){0->"SENTINEL";1->"VORTEX";else->"TITAN"}}",W()/2f,H()*0.125f,W()*0.034f,bossColor,Paint.Align.CENTER,true)

        val left=W()*0.16f; val right=W()*0.84f
        paint.color=Color.argb(90,255,255,255)
        c.drawRoundRect(left,H()*0.145f,right,H()*0.166f,10f,10f,paint)
        paint.color=bossColor
        c.drawRoundRect(left,H()*0.145f,left+(right-left)*bossHp.toFloat()/bossMaxHp.coerceAtLeast(1),H()*0.166f,10f,10f,paint)
    }

    private fun drawHowTo(c:Canvas) {
        text(c,"HOW TO PLAY",W()/2f,H()*0.15f,W()*0.065f,Color.rgb(108,255,234),Paint.Align.CENTER,true)
        val lines=listOf(
            "DRAG LEFT / RIGHT TO PILOT THE SHIP.",
            "DODGE FALLING HAZARDS AND GRAZE THEM FOR COMBOS.",
            "COLLECT COINS — THEY ARE YOUR UPGRADE CURRENCY.",
            "POWER-UPS: S = SHIELD, T = SLOW TIME, M = MAGNET,",
            "O = OVERDRIVE (FASTER AUTO-FIRE DURING BOSSES).",
            "EVERY BOSS HAS A DIFFERENT ATTACK PATTERN.",
            "SURVIVE. BUILD COMBO. BREAK BOSS RECORDS."
        )
        var y=H()*0.28f
        lines.forEach {
            text(c,it,W()/2f,y,W()*0.029f,Color.WHITE,Paint.Align.CENTER,false)
            y+=H()*0.07f
        }
        button(c,"BACK",W()/2f,H()*0.88f,W()*0.56f,H()*0.08f)
    }

    private fun drawShop(c:Canvas) {
        text(c,"HANGAR",W()/2f,H()*0.13f,W()*0.075f,Color.rgb(108,255,234),Paint.Align.CENTER,true)
        text(c,"COINS ${prefs.totalCoins}",W()/2f,H()*0.19f,W()*0.035f,Color.rgb(255,214,82),Paint.Align.CENTER,true)

        button(c,"◀  ${skinNames[selectedShopIndex]}  ▶",W()/2f,H()*0.27f,W()*0.70f,H()*0.075f)
        drawDecorativeShip(c,W()/2f,H()*0.39f)
        val i=selectedShopIndex
        val owned=prefs.ownsSkin(i)
        val action=if(owned) if(prefs.selectedSkin==i) "EQUIPPED" else "EQUIP  •  ${skinNames[i]}" else "BUY  •  ${skinCosts[i]} COINS"
        button(c,action,W()/2f,H()*0.51f,W()*0.70f,H()*0.08f,owned&&prefs.selectedSkin==i)

        text(c,"UPGRADES",W()/2f,H()*0.61f,W()*0.042f,Color.rgb(210,230,240),Paint.Align.CENTER,true)
        val names=arrayOf("BLASTER","MAGNET","SHIELD","CHRONO")
        val levels=arrayOf(prefs.blasterLevel,prefs.magnetLevel,prefs.shieldLevel,prefs.chronoLevel)
        val bases=intArrayOf(140,110,180,150)
        for(row in 0..3) {
            val yy=H()*0.66f+row*H()*0.064f
            val maxLevel=when(row){0->8;1->6;2->5;else->6}
            val label=if(levels[row]>=maxLevel) "${names[row]}  LV ${levels[row]}  MAX" else "${names[row]}  LV ${levels[row]}  •  ${bases[row]*levels[row]} COINS"
            text(c,label,W()/2f,yy,W()*0.026f,Color.WHITE,Paint.Align.CENTER,false)
        }
        text(c,"Tap an upgrade row to buy it.",W()/2f,H()*0.93f,W()*0.022f,Color.rgb(130,165,185),Paint.Align.CENTER,false)
        button(c,"BACK",W()/2f,H()*0.93f,W()*0.48f,H()*0.055f)
    }

    private fun drawSettings(c:Canvas) {
        text(c,"SETTINGS",W()/2f,H()*0.16f,W()*0.07f,Color.rgb(108,255,234),Paint.Align.CENTER,true)
        val items=arrayOf(
            "SOUND  •  ${if(prefs.sound)"ON" else "OFF"}",
            "MUSIC  •  ${if(prefs.music)"ON" else "OFF"}",
            "VIBRATION  •  ${if(prefs.vibration)"ON" else "OFF"}",
            "TRACK  •  ${musicNames[prefs.musicTrack]}"
        )
        val ys=floatArrayOf(0.35f,0.45f,0.55f,0.66f)
        for(i in items.indices) button(c,items[i],W()/2f,H()*ys[i],W()*0.78f,H()*0.07f)
        text(c,"5th track is reserved for boss battles.",W()/2f,H()*0.75f,W()*0.022f,Color.rgb(135,170,190),Paint.Align.CENTER,false)
        button(c,"BACK",W()/2f,H()*0.84f,W()*0.56f,H()*0.08f)
    }

    private fun drawOverlayPanel(c:Canvas,title:String,a:String,b:String,d:String) {
        paint.color=Color.argb(190,3,6,16)
        c.drawRect(0f,0f,W(),H(),paint)
        text(c,title,W()/2f,H()*0.27f,W()*0.075f,Color.WHITE,Paint.Align.CENTER,true)
        button(c,a,W()/2f,H()*0.48f,W()*0.55f,H()*0.08f)
        button(c,b,W()/2f,H()*0.59f,W()*0.55f,H()*0.08f)
        button(c,d,W()/2f,H()*0.70f,W()*0.55f,H()*0.08f)
    }

    private fun drawGameOver(c:Canvas) {
        drawGame(c)
        paint.color=Color.argb(205,2,5,12)
        c.drawRect(0f,0f,W(),H(),paint)
        text(c,if(newHigh)"NEW HIGH SCORE!" else "RUN OVER",W()/2f,H()*0.23f,W()*0.065f,if(newHigh)Color.rgb(255,214,82) else Color.rgb(255,90,150),Paint.Align.CENTER,true)
        text(c,"SCORE  ${score}",W()/2f,H()*0.35f,W()*0.045f,Color.WHITE,Paint.Align.CENTER,true)
        text(c,"COINS  +${runCoins}",W()/2f,H()*0.42f,W()*0.036f,Color.rgb(255,214,82),Paint.Align.CENTER,true)
        text(c,"TIME  ${String.format("%.1f",elapsed)}s",W()/2f,H()*0.49f,W()*0.031f,Color.rgb(170,210,230),Paint.Align.CENTER,false)
        text(c,"HIGH  ${prefs.highScore}",W()/2f,H()*0.55f,W()*0.028f,Color.rgb(130,170,190),Paint.Align.CENTER,false)
        button(c,"PLAY AGAIN",W()/2f,H()*0.68f,W()*0.58f,H()*0.08f,true)
        button(c,"MAIN MENU",W()/2f,H()*0.79f,W()*0.58f,H()*0.08f)
    }

    private fun button(c:Canvas,label:String,cx:Float,cy:Float,w:Float,h:Float,active:Boolean=false) {
        val rect=RectF(cx-w/2f,cy-h/2f,cx+w/2f,cy+h/2f)
        glow.color=Color.argb(if(active)100 else 55,108,255,234)
        c.drawRoundRect(RectF(rect.left-3f,rect.top-3f,rect.right+3f,rect.bottom+3f),18f,18f,glow)
        paint.color=if(active)Color.rgb(18,64,74) else Color.rgb(12,24,39)
        c.drawRoundRect(rect,18f,18f,paint)
        paint.style=Paint.Style.STROKE
        paint.strokeWidth=2f
        paint.color=if(active)Color.rgb(108,255,234) else Color.rgb(62,105,120)
        c.drawRoundRect(rect,18f,18f,paint)
        paint.style=Paint.Style.FILL
        text(c,label,cx,cy+h*0.18f,min(W()*0.032f,h*0.46f),if(active)Color.rgb(220,255,250) else Color.WHITE,Paint.Align.CENTER,true)
    }

    private fun text(c:Canvas,s:String,x:Float,y:Float,size:Float,color:Int,align:Paint.Align,bold:Boolean) {
        paint.shader=null
        paint.style=Paint.Style.FILL
        paint.color=color
        paint.textSize=size
        paint.textAlign=align
        paint.typeface=if(bold)Typeface.create(Typeface.SANS_SERIF,Typeface.BOLD) else Typeface.create(Typeface.SANS_SERIF,Typeface.NORMAL)
        paint.setShadowLayer(if(bold)3f else 0f,0f,0f,color)
        c.drawText(s,x,y,paint)
        paint.clearShadowLayer()
    }

    private fun powerColor(type:Int)=when(type){0->Color.rgb(108,255,234);1->Color.rgb(132,180,255);2->Color.rgb(255,214,82);else->Color.rgb(255,92,154)}
    private fun powerLetter(type:Int)=when(type){0->"S";1->"T";2->"M";else->"O"}

    private fun rectCircle(rx:Float,ry:Float,rw:Float,rh:Float,cx:Float,cy:Float,rad:Float):Boolean {
        val px=cx.coerceIn(rx,rx+rw)
        val py=cy.coerceIn(ry,ry+rh)
        val dx=cx-px; val dy=cy-py
        return dx*dx+dy*dy <= rad*rad
    }

    private fun circleHit(ax:Float,ay:Float,bx:Float,by:Float,r:Float):Boolean {
        val dx=ax-bx; val dy=ay-by
        return dx*dx+dy*dy <= r*r
    }

    private fun hit(x:Float,y:Float,cx:Float,cy:Float,w:Float,h:Float):Boolean =
        abs(x-cx)<=w/2f && abs(y-cy)<=h/2f

    private fun button() {
        sound.play("button",prefs.sound)
        vibrate(HapticFeedbackConstants.KEYBOARD_TAP)
    }

    private fun vibrate(type:Int) {
        if(prefs.vibration) performHapticFeedback(type)
    }

    private fun onNewFrame() {
        val now=SystemClock.uptimeMillis()
        if(lastFrame==0L) lastFrame=now
        val dt=(now-lastFrame)/1000f
        lastFrame=now
        update(dt)
    }

    fun onAppPause() {
        pausedBySystem=true
        sound.pauseMusic()
        if(screen==Screen.GAME) screen=Screen.PAUSE
    }

    fun onAppResume() {
        pausedBySystem=false
        lastFrame=SystemClock.uptimeMillis()
        if(screen==Screen.GAME) sound.resumeMusic(prefs.music,prefs.musicTrack)
    }

    fun onAppDestroy() { sound.release() }
}
