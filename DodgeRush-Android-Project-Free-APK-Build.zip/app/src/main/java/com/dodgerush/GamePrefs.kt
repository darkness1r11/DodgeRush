package com.dodgerush

import android.content.Context

class GamePrefs(context: Context) {
    private val prefs = context.getSharedPreferences("dodge_rush", Context.MODE_PRIVATE)

    var highScore: Long
        get() = prefs.getLong("high_score", 0L)
        set(value) = prefs.edit().putLong("high_score", value).apply()

    var totalCoins: Int
        get() = prefs.getInt("total_coins", 0)
        set(value) = prefs.edit().putInt("total_coins", value).apply()

    var bestTime: Float
        get() = prefs.getFloat("best_time", 0f)
        set(value) = prefs.edit().putFloat("best_time", value).apply()

    var sound: Boolean
        get() = prefs.getBoolean("sound", true)
        set(value) = prefs.edit().putBoolean("sound", value).apply()

    var music: Boolean
        get() = prefs.getBoolean("music", false)
        set(value) = prefs.edit().putBoolean("music", value).apply()

    var vibration: Boolean
        get() = prefs.getBoolean("vibration", true)
        set(value) = prefs.edit().putBoolean("vibration", value).apply()
}
