package com.dodgerush

import android.content.Context
import android.graphics.*
import android.graphics.drawable.ColorDrawable
import android.os.Build
import android.os.SystemClock
import android.view.MotionEvent
import android.view.View
import android.view.HapticFeedbackConstants
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt
import kotlin.random.Random

class DodgeRushView(context: Context) : View(context) {
    private enum class Screen { MENU, HOW_TO, SETTINGS, GAME, PAUSE, GAME_OVER }

    private data class Obstacle(var x: Float, var y: Float, var w: Float, var h: Float, var speed: Float, var rotation: Float, var spin: Float)
    private data class Coin(var x: Float, var y: Float, var r: Float, var speed: Float, var phase: Float)

    private val prefs = GamePrefs(context)
    private val sound = SoundBank(context)
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val glow = Paint(Paint.ANTI_ALIAS_FLAG)
    private val random = Random(System.nanoTime())

    private var screen = Screen.MENU
    private var lastFrame = 0L
    private var elapsed = 0f
    private var score = 0L
    private var runCoins = 0
    private var playerX = 0.5f
    private var targetX = 0.5f
    private var spawnTimer = 0f
    private var coinTimer = 0f
    private var obstacleCount = 0
    private var leftHeld = false
    private var rightHeld = false
    private var pausedBySystem = false
    private var newHigh = false
    private var particles = mutableListOf<Particle>()
    private val obstacles = mutableListOf<Obstacle>()
    private val coins = mutableListOf<Coin>()

    private data class Particle(var x: Float, var y: Float, var vx: Float, var vy: Float, var life: Float, var size: Float)

    init {
        isFocusable = true
        keepScreenOn = true
        paint.typeface = Typeface.create("sans", Typeface.NORMAL)
        glow.maskFilter = BlurMaskFilter(18f, BlurMaskFilter.Blur.NORMAL)
        setBackgroundColor(Color.rgb(7, 11, 22))
        postInvalidateOnAnimation()
    }

    private fun W() = width.toFloat()
    private fun H() = height.toFloat()

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        val now = SystemClock.uptimeMillis()
        val dt = if (lastFrame == 0L) 0.016f else ((now - lastFrame) / 1000f).coerceAtMost(0.05f)
        lastFrame = now
        if (screen == Screen.GAME && !pausedBySystem) update(dt)
        drawBackground(c)
        when (screen) {
            Screen.MENU -> drawMenu(c)
            Screen.HOW_TO -> drawHowTo(c)
            Screen.SETTINGS -> drawSettings(c)
            Screen.GAME -> drawGame(c)
            Screen.PAUSE -> { drawGame(c); drawPause(c) }
            Screen.GAME_OVER -> { drawGame(c); drawGameOver(c) }
        }
        postInvalidateOnAnimation()
    }

    private fun update(dt: Float) {
        elapsed += dt
        val difficulty = 1f + elapsed / 22f
        score = (elapsed * 10.0 * (1f + elapsed / 90f)).toLong()

        val moveSpeed = 2.6f
        if (leftHeld) targetX -= moveSpeed * dt
        if (rightHeld) targetX += moveSpeed * dt
        targetX = targetX.coerceIn(0.08f, 0.92f)
        playerX += (targetX - playerX) * min(1f, dt * 13f)

        spawnTimer -= dt
        val spawnInterval = max(0.34f, 0.95f - elapsed * 0.006f)
        if (spawnTimer <= 0f) {
            spawnTimer = spawnInterval
            spawnPattern(difficulty)
        }

        coinTimer -= dt
        if (coinTimer <= 0f) {
            coinTimer = random.nextDouble(1.0, 2.0).toFloat()
            coins += Coin(
                x = random.nextDouble(0.10, 0.90).toFloat(),
                y = -30f,
                r = min(W(), H()) * 0.022f,
                speed = H() * (0.22f + min(0.15f, elapsed / 1800f)),
                phase = random.nextFloat() * 6.28f
            )
        }

        val px = playerX * W()
        val py = H() * 0.84f
        val pr = min(W(), H()) * 0.035f

        val oi = obstacles.iterator()
        while (oi.hasNext()) {
            val o = oi.next()
            o.y += o.speed * dt
            o.rotation += o.spin * dt
            if (o.y > H() + 100f) oi.remove()
            else if (circleRectCollision(px, py, pr, o.x, o.y, o.w, o.h)) {
                crash()
                return
            }
        }

        val ci = coins.iterator()
        while (ci.hasNext()) {
            val coin = ci.next()
            coin.y += coin.speed * dt
            coin.phase += dt * 5f
            if (coin.y > H() + 60f) ci.remove()
            else if (distance(px, py, coin.x * W(), coin.y) < pr + coin.r * 1.35f) {
                runCoins++
                prefs.totalCoins = prefs.totalCoins + 1
                burst(coin.x * W(), coin.y, 14)
                sound.play("coin", prefs.sound)
                vibrate(HapticFeedbackConstants.KEYBOARD_TAP)
                ci.remove()
            }
        }

        val pi = particles.iterator()
        while (pi.hasNext()) {
            val p = pi.next()
            p.x += p.vx * dt
            p.y += p.vy * dt
            p.vy += 90f * dt
            p.life -= dt
            if (p.life <= 0) pi.remove()
        }
    }

    private fun spawnPattern(difficulty: Float) {
        obstacleCount++
        val speedBase = H() * (0.22f + min(0.20f, difficulty * 0.018f))
        val mode = obstacleCount % 5
        when (mode) {
            0, 1, 2 -> addObstacle(random.nextDouble(0.08, 0.88).toFloat(), speedBase)
            3 -> {
                val gap = random.nextDouble(0.30, 0.62).toFloat()
                addObstacle(gap - 0.22f, speedBase * 0.95f, 0.17f)
                addObstacle(gap + 0.15f, speedBase * 0.95f, 0.17f)
            }
            else -> {
                val x = random.nextDouble(0.18, 0.82).toFloat()
                addObstacle(x - 0.16f, speedBase, 0.13f)
                addObstacle(x + 0.16f, speedBase * 1.05f, 0.13f)
            }
        }
    }

    private fun addObstacle(normX: Float, speed: Float, widthNorm: Float = 0.20f) {
        val w = W() * widthNorm.coerceIn(0.11f, 0.22f)
        obstacles += Obstacle(
            x = (normX.coerceIn(0.03f, 0.97f - widthNorm)) * W(),
            y = -H() * 0.10f,
            w = w,
            h = w * random.nextDouble(0.65, 1.05).toFloat(),
            speed = speed * random.nextDouble(0.88, 1.12).toFloat(),
            rotation = random.nextFloat() * 360f,
            spin = random.nextDouble(-70.0, 70.0).toFloat()
        )
    }

    private fun crash() {
        sound.play("collision", prefs.sound)
        vibrate(HapticFeedbackConstants.LONG_PRESS)
        burst(playerX * W(), H() * 0.84f, 30)
        sound.play("gameover", prefs.sound)
        val old = prefs.highScore
        newHigh = score > old
        if (newHigh) {
            prefs.highScore = score
            sound.play("highscore", prefs.sound)
        }
        if (elapsed > prefs.bestTime) prefs.bestTime = elapsed
        screen = Screen.GAME_OVER
    }

    private fun burst(x: Float, y: Float, n: Int) {
        repeat(n) {
            val a = random.nextDouble(0.0, Math.PI * 2).toFloat()
            val s = random.nextDouble(40.0, 180.0).toFloat()
            particles += Particle(x, y, kotlin.math.cos(a) * s, kotlin.math.sin(a) * s, 0.55f, random.nextDouble(2.0, 5.0).toFloat())
        }
    }

    private fun circleRectCollision(cx: Float, cy: Float, r: Float, x: Float, y: Float, w: Float, h: Float): Boolean {
        val nx = cx.coerceIn(x, x + w)
        val ny = cy.coerceIn(y, y + h)
        return distance(cx, cy, nx, ny) < r * 0.88f
    }

    private fun distance(a: Float, b: Float, c: Float, d: Float) =
        sqrt((a - c) * (a - c) + (b - d) * (b - d))

    private fun drawBackground(c: Canvas) {
        c.drawColor(Color.rgb(7, 11, 22))
        paint.shader = LinearGradient(0f, 0f, 0f, H(), Color.rgb(9, 17, 35), Color.rgb(4, 7, 15), Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, W(), H(), paint)
        paint.shader = null
        paint.color = Color.argb(22, 108, 255, 234)
        for (i in 0..10) {
            val y = H() * i / 10f
            c.drawRect(0f, y, W(), y + 1f, paint)
        }
    }

    private fun text(c: Canvas, s: String, x: Float, y: Float, size: Float, color: Int, align: Paint.Align = Paint.Align.LEFT, bold: Boolean = false) {
        paint.shader = null
        paint.style = Paint.Style.FILL
        paint.color = color
        paint.textSize = size
        paint.textAlign = align
        paint.typeface = Typeface.create("sans", if (bold) Typeface.BOLD else Typeface.NORMAL)
        c.drawText(s, x, y, paint)
    }

    private fun button(c: Canvas, label: String, cx: Float, cy: Float, w: Float, h: Float, accent: Boolean = false) {
        paint.style = Paint.Style.FILL
        paint.color = if (accent) Color.rgb(26, 80, 86) else Color.rgb(18, 28, 48)
        c.drawRoundRect(cx - w/2, cy - h/2, cx + w/2, cy + h/2, h/2, h/2, paint)
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 2f
        paint.color = if (accent) Color.rgb(108, 255, 234) else Color.rgb(52, 75, 105)
        c.drawRoundRect(cx - w/2, cy - h/2, cx + w/2, cy + h/2, h/2, h/2, paint)
        paint.style = Paint.Style.FILL
        text(c, label, cx, cy + h*0.13f, h*0.30f, Color.WHITE, Paint.Align.CENTER, true)
    }

    private fun drawTitle(c: Canvas, y: Float) {
        glow.color = Color.argb(120, 70, 255, 230)
        c.drawCircle(W()/2, y-12f, 45f, glow)
        text(c, "DODGE", W()/2, y, min(W(), H())*0.11f, Color.WHITE, Paint.Align.CENTER, true)
        text(c, "RUSH", W()/2, y + min(W(), H())*0.09f, min(W(), H())*0.11f, Color.rgb(108,255,234), Paint.Align.CENTER, true)
    }

    private fun drawMenu(c: Canvas) {
        drawTitle(c, H()*0.20f)
        text(c, "SURVIVE • DODGE • COLLECT", W()/2, H()*0.34f, min(W(),H())*0.034f, Color.rgb(150,175,205), Paint.Align.CENTER, false)
        val bw = W()*0.66f
        val bh = H()*0.072f
        button(c, "PLAY", W()/2, H()*0.48f, bw, bh, true)
        button(c, "HOW TO PLAY", W()/2, H()*0.58f, bw, bh)
        button(c, "SETTINGS", W()/2, H()*0.68f, bw, bh)
        statsRow(c, H()*0.84f)
    }

    private fun statsRow(c: Canvas, y: Float) {
        val x = W()/2
        text(c, "HIGH SCORE", x - W()*0.30f, y, W()*0.028f, Color.rgb(120,145,175), Paint.Align.CENTER, true)
        text(c, prefs.highScore.toString(), x - W()*0.30f, y + W()*0.045f, W()*0.05f, Color.WHITE, Paint.Align.CENTER, true)
        text(c, "COINS", x, y, W()*0.028f, Color.rgb(120,145,175), Paint.Align.CENTER, true)
        text(c, prefs.totalCoins.toString(), x, y + W()*0.045f, W()*0.05f, Color.rgb(255,214,82), Paint.Align.CENTER, true)
        text(c, "BEST TIME", x + W()*0.30f, y, W()*0.028f, Color.rgb(120,145,175), Paint.Align.CENTER, true)
        text(c, formatTime(prefs.bestTime), x + W()*0.30f, y + W()*0.045f, W()*0.05f, Color.WHITE, Paint.Align.CENTER, true)
    }

    private fun drawHowTo(c: Canvas) {
        text(c, "HOW TO PLAY", W()/2, H()*0.12f, W()*0.075f, Color.WHITE, Paint.Align.CENTER, true)
        text(c, "Move left and right to stay clear of the falling", W()/2, H()*0.28f, W()*0.038f, Color.rgb(190,205,225), Paint.Align.CENTER)
        text(c, "obstacles. Collect glowing coins for your total.", W()/2, H()*0.33f, W()*0.038f, Color.rgb(190,205,225), Paint.Align.CENTER)
        text(c, "The longer you survive, the faster it gets.", W()/2, H()*0.42f, W()*0.038f, Color.rgb(190,205,225), Paint.Align.CENTER)
        text(c, "Touch / drag left or right • Keyboard: A/D or ←/→", W()/2, H()*0.53f, W()*0.033f, Color.rgb(108,255,234), Paint.Align.CENTER)
        button(c, "BACK", W()/2, H()*0.78f, W()*0.50f, H()*0.075f)
    }

    private fun drawSettings(c: Canvas) {
        text(c, "SETTINGS", W()/2, H()*0.12f, W()*0.075f, Color.WHITE, Paint.Align.CENTER, true)
        settingRow(c, "SOUND", prefs.sound, H()*0.30f)
        settingRow(c, "MUSIC", prefs.music, H()*0.42f)
        settingRow(c, "VIBRATION", prefs.vibration, H()*0.54f)
        text(c, "Music is disabled by default because this build", W()/2, H()*0.66f, W()*0.030f, Color.rgb(120,145,175), Paint.Align.CENTER)
        text(c, "ships with lightweight sound effects only.", W()/2, H()*0.70f, W()*0.030f, Color.rgb(120,145,175), Paint.Align.CENTER)
        button(c, "BACK", W()/2, H()*0.82f, W()*0.50f, H()*0.075f)
    }

    private fun settingRow(c: Canvas, label: String, enabled: Boolean, y: Float) {
        text(c, label, W()*0.20f, y+10f, W()*0.04f, Color.WHITE, Paint.Align.LEFT, true)
        button(c, if (enabled) "ON" else "OFF", W()*0.76f, y, W()*0.24f, H()*0.065f, enabled)
    }

    private fun drawGame(c: Canvas) {
        val px = playerX * W()
        val py = H()*0.84f
        val r = min(W(),H())*0.035f

        // HUD
        text(c, "SCORE  $score", W()*0.055f, H()*0.065f, W()*0.042f, Color.WHITE, Paint.Align.LEFT, true)
        text(c, "● $runCoins", W()*0.55f, H()*0.065f, W()*0.042f, Color.rgb(255,214,82), Paint.Align.LEFT, true)
        button(c, "Ⅱ", W()*0.91f, H()*0.055f, W()*0.12f, H()*0.055f)

        // Player glow and ship
        glow.color = Color.argb(115, 108, 255, 234)
        c.drawCircle(px, py, r*1.9f, glow)
        paint.color = Color.rgb(108,255,234)
        paint.style = Paint.Style.FILL
        val ship = Path()
        ship.moveTo(px, py-r*1.25f)
        ship.lineTo(px-r*0.95f, py+r)
        ship.lineTo(px, py+r*0.55f)
        ship.lineTo(px+r*0.95f, py+r)
        ship.close()
        c.drawPath(ship, paint)
        paint.color = Color.rgb(7, 30, 40)
        c.drawCircle(px, py-r*0.25f, r*0.28f, paint)

        for (o in obstacles) {
            paint.color = Color.rgb(255, 78, 120)
            paint.style = Paint.Style.FILL
            c.save()
            c.rotate(o.rotation, o.x+o.w/2, o.y+o.h/2)
            c.drawRoundRect(o.x, o.y, o.x+o.w, o.y+o.h, o.w*0.18f, o.w*0.18f, paint)
            paint.color = Color.rgb(95, 16, 55)
            c.drawCircle(o.x+o.w*0.5f, o.y+o.h*0.5f, min(o.w,o.h)*0.18f, paint)
            c.restore()
        }

        for (coin in coins) {
            val pulse = 1f + 0.12f * kotlin.math.sin(coin.phase)
            glow.color = Color.argb(100, 255, 214, 82)
            c.drawCircle(coin.x*W(), coin.y, coin.r*1.6f, glow)
            paint.color = Color.rgb(255,214,82)
            c.drawCircle(coin.x*W(), coin.y, coin.r*pulse, paint)
            paint.color = Color.rgb(130,92,15)
            c.drawCircle(coin.x*W(), coin.y, coin.r*0.52f, paint)
        }

        for (p in particles) {
            paint.color = Color.argb((255f*(p.life/0.55f)).toInt().coerceIn(0,255), 108, 255, 234)
            c.drawCircle(p.x, p.y, p.size, paint)
        }
    }

    private fun drawPause(c: Canvas) {
        overlay(c)
        text(c, "PAUSED", W()/2, H()*0.28f, W()*0.09f, Color.WHITE, Paint.Align.CENTER, true)
        button(c, "RESUME", W()/2, H()*0.44f, W()*0.62f, H()*0.075f, true)
        button(c, "RESTART", W()/2, H()*0.54f, W()*0.62f, H()*0.075f)
        button(c, "MAIN MENU", W()/2, H()*0.64f, W()*0.62f, H()*0.075f)
    }

    private fun drawGameOver(c: Canvas) {
        overlay(c)
        text(c, if (newHigh) "NEW HIGH SCORE!" else "GAME OVER", W()/2, H()*0.25f, W()*0.075f, if (newHigh) Color.rgb(108,255,234) else Color.WHITE, Paint.Align.CENTER, true)
        text(c, "SCORE", W()*0.28f, H()*0.37f, W()*0.03f, Color.rgb(130,155,185), Paint.Align.CENTER, true)
        text(c, score.toString(), W()*0.28f, H()*0.42f, W()*0.055f, Color.WHITE, Paint.Align.CENTER, true)
        text(c, "COINS", W()*0.50f, H()*0.37f, W()*0.03f, Color.rgb(130,155,185), Paint.Align.CENTER, true)
        text(c, runCoins.toString(), W()*0.50f, H()*0.42f, W()*0.055f, Color.rgb(255,214,82), Paint.Align.CENTER, true)
        text(c, "TIME", W()*0.72f, H()*0.37f, W()*0.03f, Color.rgb(130,155,185), Paint.Align.CENTER, true)
        text(c, formatTime(elapsed), W()*0.72f, H()*0.42f, W()*0.055f, Color.WHITE, Paint.Align.CENTER, true)
        button(c, "PLAY AGAIN", W()/2, H()*0.58f, W()*0.65f, H()*0.075f, true)
        button(c, "MAIN MENU", W()/2, H()*0.68f, W()*0.65f, H()*0.075f)
    }

    private fun overlay(c: Canvas) {
        paint.color = Color.argb(195, 3, 7, 15)
        c.drawRect(0f,0f,W(),H(),paint)
    }

    private fun formatTime(t: Float): String {
        val total = t.toInt()
        return "%02d:%02d".format(total / 60, total % 60)
    }

    private fun startGame() {
        screen = Screen.GAME
        elapsed = 0f
        score = 0
        runCoins = 0
        playerX = 0.5f
        targetX = 0.5f
        spawnTimer = 0.15f
        coinTimer = 0.8f
        obstacleCount = 0
        obstacles.clear()
        coins.clear()
        particles.clear()
        newHigh = false
        sound.play("button", prefs.sound)
    }

    private fun vibrate(type: Int) {
        if (prefs.vibration) performHapticFeedback(type)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val x = e.x
        val y = e.y
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                when (screen) {
                    Screen.MENU -> {
                        if (hit(x,y,W()/2,H()*0.48f,W()*0.66f,H()*0.072f)) startGame()
                        else if (hit(x,y,W()/2,H()*0.58f,W()*0.66f,H()*0.072f)) { screen=Screen.HOW_TO; sound.play("button",prefs.sound) }
                        else if (hit(x,y,W()/2,H()*0.68f,W()*0.66f,H()*0.072f)) { screen=Screen.SETTINGS; sound.play("button",prefs.sound) }
                    }
                    Screen.HOW_TO -> if (hit(x,y,W()/2,H()*0.78f,W()*0.50f,H()*0.075f)) { screen=Screen.MENU; sound.play("button",prefs.sound) }
                    Screen.SETTINGS -> settingsTouch(x,y)
                    Screen.GAME -> {
                        if (hit(x,y,W()*0.91f,H()*0.055f,W()*0.12f,H()*0.055f)) { screen=Screen.PAUSE; sound.play("button",prefs.sound) }
                        else targetX = (x/W()).coerceIn(0.08f,0.92f)
                    }
                    Screen.PAUSE -> pauseTouch(x,y)
                    Screen.GAME_OVER -> gameOverTouch(x,y)
                }
                return true
            }
            MotionEvent.ACTION_MOVE -> if (screen == Screen.GAME) {
                targetX = (x/W()).coerceIn(0.08f,0.92f)
                return true
            }
        }
        return true
    }

    private fun settingsTouch(x:Float,y:Float) {
        when {
            hit(x,y,W()*0.76f,H()*0.30f,W()*0.24f,H()*0.065f) -> { prefs.sound=!prefs.sound; vibrate(HapticFeedbackConstants.KEYBOARD_TAP) }
            hit(x,y,W()*0.76f,H()*0.42f,W()*0.24f,H()*0.065f) -> { prefs.music=!prefs.music; vibrate(HapticFeedbackConstants.KEYBOARD_TAP) }
            hit(x,y,W()*0.76f,H()*0.54f,W()*0.24f,H()*0.065f) -> { prefs.vibration=!prefs.vibration }
            hit(x,y,W()/2,H()*0.82f,W()*0.50f,H()*0.075f) -> { screen=Screen.MENU; sound.play("button",prefs.sound) }
        }
    }

    private fun pauseTouch(x:Float,y:Float) {
        when {
            hit(x,y,W()/2,H()*0.44f,W()*0.62f,H()*0.075f) -> { screen=Screen.GAME; sound.play("button",prefs.sound) }
            hit(x,y,W()/2,H()*0.54f,W()*0.62f,H()*0.075f) -> startGame()
            hit(x,y,W()/2,H()*0.64f,W()*0.62f,H()*0.075f) -> { screen=Screen.MENU; sound.play("button",prefs.sound) }
        }
    }

    private fun gameOverTouch(x:Float,y:Float) {
        when {
            hit(x,y,W()/2,H()*0.58f,W()*0.65f,H()*0.075f) -> startGame()
            hit(x,y,W()/2,H()*0.68f,W()*0.65f,H()*0.075f) -> { screen=Screen.MENU; sound.play("button",prefs.sound) }
        }
    }

    private fun hit(px:Float,py:Float,cx:Float,cy:Float,w:Float,h:Float) =
        abs(px-cx) <= w/2 && abs(py-cy) <= h/2

    fun onAppPause() {
        pausedBySystem = true
        if (screen == Screen.GAME) screen = Screen.PAUSE
    }

    fun onAppResume() {
        pausedBySystem = false
        lastFrame = SystemClock.uptimeMillis()
    }

    override fun onKeyDown(keyCode: Int, event: android.view.KeyEvent): Boolean {
        if (screen == Screen.GAME) {
            when (keyCode) {
                android.view.KeyEvent.KEYCODE_A, android.view.KeyEvent.KEYCODE_DPAD_LEFT -> { leftHeld=true; return true }
                android.view.KeyEvent.KEYCODE_D, android.view.KeyEvent.KEYCODE_DPAD_RIGHT -> { rightHeld=true; return true }
                android.view.KeyEvent.KEYCODE_ESCAPE -> { screen=Screen.PAUSE; return true }
            }
        }
        return super.onKeyDown(keyCode,event)
    }

    override fun onKeyUp(keyCode: Int, event: android.view.KeyEvent): Boolean {
        when (keyCode) {
            android.view.KeyEvent.KEYCODE_A, android.view.KeyEvent.KEYCODE_DPAD_LEFT -> leftHeld=false
            android.view.KeyEvent.KEYCODE_D, android.view.KeyEvent.KEYCODE_DPAD_RIGHT -> rightHeld=false
        }
        return super.onKeyUp(keyCode,event)
    }

    override fun onDetachedFromWindow() {
        sound.release()
        super.onDetachedFromWindow()
    }
}
