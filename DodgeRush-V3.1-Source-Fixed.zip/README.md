# Dodge Rush V3 — Boss Rush Edition

A portrait, offline-first Android arcade game built with native Kotlin + Canvas.

## Major features
- 7 ship skins with coin-priced unlocks
- Coin-based Hangar shop
- Four permanent upgrades: Blaster, Magnet, Shield, Chrono
- Four power-ups: Shield, Slow Time, Magnet, Overdrive
- Combo / near-miss bonus
- Endless difficulty and level progression
- Boss fights every ~45 seconds with 3 different bosses:
  Sentinel, Vortex, Titan
- Boss health bars, projectile patterns, warning phase, rewards
- Five local, non-silent soundtrack loops:
  Neon Run, Pulse Reactor, Night Drive, Velocity, Boss Protocol
- Local SFX in resources
- No ads, analytics, accounts, backend, or INTERNET permission
- Android 8+ (API 26)
- All persistent progress is stored locally with SharedPreferences

## GitHub phone build
The included workflow expects a single file in the GitHub repository root:

DodgeRush-V3-Source.zip

Upload that ZIP plus `.github/workflows/build-apk.yml`, or use the workflow already included in the extracted source.

Then:
1. GitHub → Actions
2. Build Dodge Rush APK
3. Run workflow (or push a new commit)
4. Wait for Success
5. Open the run → Artifacts → DodgeRush-V3-APK
6. Download the artifact ZIP, extract it, install `app-debug.apk`

For a repository containing extracted project files directly, use a workflow that runs `gradle assembleDebug` without the ZIP extraction step.
