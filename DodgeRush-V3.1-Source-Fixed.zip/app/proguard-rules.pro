# Dodge Rush V3 uses no custom ProGuard rules.
