package com.dodgerush

import android.content.Context

class GamePrefs(context: Context) {
    private val p = context.getSharedPreferences("dodge_rush_v3", Context.MODE_PRIVATE)

    var highScore: Long
        get() = p.getLong("high_score", 0L)
        set(v) { p.edit().putLong("high_score", v).apply() }

    var totalCoins: Long
        get() = p.getLong("total_coins", 0L)
        set(v) { p.edit().putLong("total_coins", v).apply() }

    var bestTime: Float
        get() = p.getFloat("best_time", 0f)
        set(v) { p.edit().putFloat("best_time", v).apply() }

    var sound: Boolean
        get() = p.getBoolean("sound", true)
        set(v) { p.edit().putBoolean("sound", v).apply() }

    var music: Boolean
        get() = p.getBoolean("music", true)
        set(v) { p.edit().putBoolean("music", v).apply() }

    var vibration: Boolean
        get() = p.getBoolean("vibration", true)
        set(v) { p.edit().putBoolean("vibration", v).apply() }

    var musicTrack: Int
        get() = p.getInt("music_track", 0)
        set(v) { p.edit().putInt("music_track", v.coerceIn(0, 4)).apply() }

    var selectedSkin: Int
        get() = p.getInt("selected_skin", 0)
        set(v) { p.edit().putInt("selected_skin", v).apply() }

    var ownedSkins: String
        get() = p.getString("owned_skins", "0") ?: "0"
        set(v) { p.edit().putString("owned_skins", v).apply() }

    var blasterLevel: Int
        get() = p.getInt("blaster_level", 1)
        set(v) { p.edit().putInt("blaster_level", v.coerceIn(1, 8)).apply() }

    var magnetLevel: Int
        get() = p.getInt("magnet_level", 1)
        set(v) { p.edit().putInt("magnet_level", v.coerceIn(1, 6)).apply() }

    var shieldLevel: Int
        get() = p.getInt("shield_level", 1)
        set(v) { p.edit().putInt("shield_level", v.coerceIn(1, 5)).apply() }

    var chronoLevel: Int
        get() = p.getInt("chrono_level", 1)
        set(v) { p.edit().putInt("chrono_level", v.coerceIn(1, 6)).apply() }

    var bossesDefeated: Int
        get() = p.getInt("bosses_defeated", 0)
        set(v) { p.edit().putInt("bosses_defeated", v).apply() }

    fun ownsSkin(index: Int): Boolean =
        ownedSkins.split(',').mapNotNull { it.toIntOrNull() }.contains(index)

    fun unlockSkin(index: Int) {
        if (!ownsSkin(index)) {
            val set = (ownedSkins.split(',').mapNotNull { it.toIntOrNull() } + index).distinct()
            ownedSkins = set.joinToString(",")
        }
    }

    fun upgradeCost(level: Int, base: Int): Int = base * level
}
