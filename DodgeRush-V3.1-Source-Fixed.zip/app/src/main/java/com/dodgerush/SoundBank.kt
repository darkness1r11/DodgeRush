package com.dodgerush

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.SoundPool

class SoundBank(private val context: Context) {
    private val pool: SoundPool
    private val ids = HashMap<String, Int>()
    private var musicPlayer: MediaPlayer? = null
    private var currentTrack = -1

    private val trackIds = intArrayOf(
        R.raw.neon_run,
        R.raw.pulse_reactor,
        R.raw.night_drive,
        R.raw.velocity,
        R.raw.boss_protocol
    )

    init {
        val attrs = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_GAME)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()
        pool = SoundPool.Builder()
            .setAudioAttributes(attrs)
            .setMaxStreams(8)
            .build()

        load("button", R.raw.sfx_button)
        load("coin", R.raw.sfx_coin)
        load("hit", R.raw.sfx_hit)
        load("power", R.raw.sfx_power)
        load("warning", R.raw.sfx_warning)
        load("shoot", R.raw.sfx_shoot)
        load("bossdown", R.raw.sfx_bossdown)
        load("gameover", R.raw.sfx_gameover)
    }

    private fun load(name: String, resId: Int) {
        ids[name] = pool.load(context, resId, 1)
    }

    fun play(name: String, enabled: Boolean) {
        if (!enabled) return
        ids[name]?.let { pool.play(it, 0.9f, 0.9f, 1, 0, 1f) }
    }

    fun setMusic(enabled: Boolean, track: Int) {
        if (!enabled) {
            musicPlayer?.pause()
            return
        }
        val clamped = track.coerceIn(0, trackIds.lastIndex)
        if (musicPlayer == null || currentTrack != clamped) {
            musicPlayer?.release()
            musicPlayer = MediaPlayer.create(context, trackIds[clamped])?.also { mp ->
                mp.isLooping = true
                mp.setVolume(0.32f, 0.32f)
            }
            currentTrack = if (musicPlayer != null) clamped else -1
        }
        musicPlayer?.start()
    }

    fun bossMusic(enabled: Boolean) {
        if (enabled) setMusic(true, 4)
    }

    fun normalMusic(enabled: Boolean, track: Int) {
        if (enabled) setMusic(true, track.coerceIn(0, 3))
    }

    fun pauseMusic() {
        musicPlayer?.pause()
    }

    fun resumeMusic(enabled: Boolean, track: Int) {
        if (enabled) setMusic(true, track) else musicPlayer?.pause()
    }

    fun release() {
        musicPlayer?.release()
        musicPlayer = null
        currentTrack = -1
        pool.release()
    }
}
